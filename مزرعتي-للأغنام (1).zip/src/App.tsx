/**
 * Mazraati Sheep (مزرعتي للأغنام)
 * Native Android Experience App
 * Package: com.mazraati.sheep
 */

import React, { useState, useEffect } from 'react';
import { NavigationSection } from './types';
import { SheepDB } from './store/database';
import { AndroidTopBar } from './components/AndroidTopBar';
import { AndroidBottomNav } from './components/AndroidBottomNav';
import { AndroidDrawer } from './components/AndroidDrawer';
import { DashboardView } from './views/DashboardView';
import { AnimalsView } from './views/AnimalsView';
import { ReproductionView } from './views/ReproductionView';
import { HealthView } from './views/HealthView';
import { FeedingView } from './views/FeedingView';
import { ExpensesView } from './views/ExpensesView';
import { IncomeView } from './views/IncomeView';
import { ReportsView } from './views/ReportsView';
import { RemindersView } from './views/RemindersView';
import { BackupSettingsView } from './views/BackupSettingsView';
import { AndroidCodeExportView } from './views/AndroidCodeExportView';
import { AnimalFormModal } from './views/AnimalFormModal';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export default function App() {
  const [currentSection, setCurrentSection] = useState<NavigationSection>('dashboard');
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [isAddAnimalOpen, setIsAddAnimalOpen] = useState(false);
  const [isAddExpenseOpen, setIsAddExpenseOpen] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // PWA Install state
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if running as standalone PWA
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallApp = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      alert('لتثبيت التطبيق على هاتفك الأندرويد، اضغط على زر القائمة (الثلاث نقاط) في متصفح كروم ثم اختر "إضافة إلى الشاشة الرئيسية" أو "تثبيت التطبيق".');
    }
  };

  const handleRefresh = () => {
    setRefreshTrigger((prev) => prev + 1);
  };

  const unreadReminders = SheepDB.getReminders().filter((r) => !r.isCompleted).length;

  return (
    <div className="min-h-screen bg-stone-100 flex flex-col font-sans select-none text-stone-900 pb-safe">
      {/* Phone container constraint on large screens for true mobile phone feeling */}
      <div className="w-full max-w-xl mx-auto min-h-screen bg-stone-50 flex flex-col shadow-xl relative border-x border-stone-200/50">
        {/* Top App Bar */}
        <AndroidTopBar
          currentSection={currentSection}
          onOpenDrawer={() => setIsDrawerOpen(true)}
          onNavigate={(sec) => setCurrentSection(sec)}
          unreadRemindersCount={unreadReminders}
          isInstallable={!isInstalled && !!deferredPrompt}
          onInstallApp={handleInstallApp}
        />

        {/* Main Content View Container */}
        <main className="flex-1 p-3.5 pt-3 overflow-y-auto">
          {currentSection === 'dashboard' && (
            <DashboardView
              onNavigate={(sec) => setCurrentSection(sec)}
              onOpenAddAnimal={() => setIsAddAnimalOpen(true)}
              onOpenAddExpense={() => {
                setCurrentSection('expenses');
                setIsAddExpenseOpen(true);
              }}
              onOpenAddBreeding={() => setCurrentSection('reproduction')}
              onOpenAddHealth={() => setCurrentSection('health')}
            />
          )}

          {currentSection === 'animals' && (
            <AnimalsView onOpenAddModal={() => setIsAddAnimalOpen(true)} />
          )}

          {currentSection === 'reproduction' && <ReproductionView />}

          {currentSection === 'health' && <HealthView />}

          {currentSection === 'feeding' && <FeedingView />}

          {currentSection === 'expenses' && (
            <ExpensesView
              isAddModalOpenProp={isAddExpenseOpen}
              onCloseAddModalProp={() => setIsAddExpenseOpen(false)}
            />
          )}

          {currentSection === 'income' && <IncomeView />}

          {currentSection === 'reports' && <ReportsView />}

          {currentSection === 'reminders' && <RemindersView />}

          {currentSection === 'backup' && <BackupSettingsView />}

          {currentSection === 'android_code' && <AndroidCodeExportView />}
        </main>

        {/* Bottom Navigation Bar */}
        <AndroidBottomNav
          currentSection={currentSection}
          onSelectSection={(sec) => setCurrentSection(sec)}
          onOpenDrawer={() => setIsDrawerOpen(true)}
        />

        {/* Navigation Drawer */}
        <AndroidDrawer
          isOpen={isDrawerOpen}
          onClose={() => setIsDrawerOpen(false)}
          currentSection={currentSection}
          onSelectSection={(sec) => setCurrentSection(sec)}
          unreadRemindersCount={unreadReminders}
        />

        {/* Quick Add Animal Modal */}
        <AnimalFormModal
          isOpen={isAddAnimalOpen}
          onClose={() => setIsAddAnimalOpen(false)}
          onSave={handleRefresh}
        />
      </div>
    </div>
  );
}
