import React, { useState } from 'react';
import {
  X,
  Edit2,
  Trash2,
  Calendar,
  Activity,
  Heart,
  DollarSign,
  AlertTriangle,
  CheckCircle,
  Skull,
  Share2,
} from 'lucide-react';
import { Animal } from '../types';
import { SheepDB } from '../store/database';
import {
  calculateAgeArabic,
  formatDateArabic,
  formatDualCurrency,
} from '../utils/formatters';
import { CurrencyInput } from '../components/CurrencyInput';

interface AnimalDetailModalProps {
  animal: Animal | null;
  onClose: () => void;
  onEdit: (animal: Animal) => void;
  onRefresh: () => void;
}

export const AnimalDetailModal: React.FC<AnimalDetailModalProps> = ({
  animal,
  onClose,
  onEdit,
  onRefresh,
}) => {
  const [showSoldModal, setShowSoldModal] = useState(false);
  const [showDeadModal, setShowDeadModal] = useState(false);
  const [salePriceCentimes, setSalePriceCentimes] = useState(0);
  const [saleDate, setSaleDate] = useState(new Date().toISOString().split('T')[0]);
  const [saleNotes, setSaleNotes] = useState('');
  const [deathDate, setDeathDate] = useState(new Date().toISOString().split('T')[0]);
  const [deathReason, setDeathReason] = useState('');

  if (!animal) return null;

  const ageText = calculateAgeArabic(animal.birthDate);
  const healthRecords = SheepDB.getHealthRecords().filter(
    (h) => h.animalId === animal.id || h.animalId === 'all'
  );
  const breedings = SheepDB.getBreedings().filter(
    (b) => b.motherId === animal.id || b.ramId === animal.id
  );

  const handleConfirmSold = () => {
    SheepDB.markAnimalSold(animal.id, salePriceCentimes, saleDate, saleNotes);
    setShowSoldModal(false);
    onRefresh();
    onClose();
  };

  const handleConfirmDead = () => {
    SheepDB.markAnimalDead(animal.id, deathDate, deathReason);
    setShowDeadModal(false);
    onRefresh();
    onClose();
  };

  const handleDelete = () => {
    if (confirm(`هل أنت متأكد من حذف الرأس (${animal.id}) نهائياً من السجل؟`)) {
      SheepDB.deleteAnimal(animal.id);
      onRefresh();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
          <div className="flex items-center gap-3">
            <span
              className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm ${
                animal.sex === 'female' ? 'bg-pink-500 text-white' : 'bg-blue-600 text-white'
              }`}
            >
              {animal.id}
            </span>
            <div>
              <h2 className="text-base font-bold leading-tight">
                {animal.sex === 'female' ? 'نعجة' : 'كبش'} رقم {animal.id}
              </h2>
              <span className="text-[11px] text-emerald-200 font-medium">
                {animal.status === 'healthy'
                  ? 'سليم / بصحة جيدة'
                  : animal.status === 'pregnant'
                  ? 'حامل (قيد الانتظار)'
                  : animal.status === 'sick'
                  ? 'مريض / قيد العلاج'
                  : animal.status === 'sold'
                  ? 'تم البيع'
                  : 'نافق / ميت'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => onEdit(animal)}
              className="p-2 rounded-full hover:bg-white/10 text-white"
              title="تعديل البيانات"
            >
              <Edit2 size={16} />
            </button>
            <button
              type="button"
              onClick={handleDelete}
              className="p-2 rounded-full hover:bg-red-500/30 text-red-300"
              title="حذف السجل"
            >
              <Trash2 size={16} />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-full hover:bg-white/10 text-white"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4 text-xs text-stone-700">
          {/* Main Card with Photo & Vital Stats */}
          <div className="flex gap-4 p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80">
            {animal.photo ? (
              <img
                src={animal.photo}
                alt={animal.id}
                className="w-24 h-24 object-cover rounded-xl border border-stone-300 shadow-xs shrink-0"
              />
            ) : (
              <div className="w-24 h-24 rounded-xl bg-emerald-100/60 border border-emerald-300/60 flex flex-col items-center justify-center text-emerald-900 shrink-0">
                <span className="text-3xl">🐑</span>
                <span className="text-[10px] font-bold mt-1">{animal.id}</span>
              </div>
            )}

            <div className="flex-1 space-y-1.5 min-w-0">
              <div className="flex items-center justify-between">
                <span className="text-stone-500">الجنس:</span>
                <span className="font-bold text-stone-900">
                  {animal.sex === 'female' ? 'أنثى (نعجة)' : 'ذكر (كبش)'}
                </span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-stone-500">العمر الحالي:</span>
                <span className="font-bold text-emerald-800">{ageText}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-stone-500">تاريخ الميلاد:</span>
                <span className="font-medium text-stone-800">{formatDateArabic(animal.birthDate)}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-stone-500">المصدر:</span>
                <span className="font-medium text-stone-800">
                  {animal.source === 'purchase' ? 'شراء' : 'ولادة في المزرعة'}
                </span>
              </div>
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="p-2.5 rounded-xl bg-white border border-stone-200">
              <span className="text-stone-400 block text-[11px]">اللون:</span>
              <span className="font-bold text-stone-900">{animal.color || 'غير محدد'}</span>
            </div>

            <div className="p-2.5 rounded-xl bg-white border border-stone-200">
              <span className="text-stone-400 block text-[11px]">العلامات:</span>
              <span className="font-bold text-stone-900">{animal.markings || 'لا توجد علامات'}</span>
            </div>

            {animal.motherId && (
              <div className="p-2.5 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-400 block text-[11px]">النعجة الأم:</span>
                <span className="font-bold text-pink-700">{animal.motherId}</span>
              </div>
            )}

            {animal.fatherId && (
              <div className="p-2.5 rounded-xl bg-white border border-stone-200">
                <span className="text-stone-400 block text-[11px]">الكبش الأب:</span>
                <span className="font-bold text-blue-700">{animal.fatherId}</span>
              </div>
            )}

            {animal.purchasePriceCentimes ? (
              <div className="p-2.5 rounded-xl bg-white border border-stone-200 col-span-2">
                <span className="text-stone-400 block text-[11px]">سعر الشراء:</span>
                <span className="font-bold text-stone-900 tabular-nums">
                  {formatDualCurrency(animal.purchasePriceCentimes)}
                </span>
              </div>
            ) : null}

            {animal.salePriceCentimes ? (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 col-span-2">
                <span className="text-emerald-700 block text-[11px]">سعر البيع وتاريخه:</span>
                <span className="font-bold text-emerald-900 tabular-nums">
                  {formatDualCurrency(animal.salePriceCentimes)} · {formatDateArabic(animal.saleDate || '')}
                </span>
              </div>
            ) : null}

            {animal.deathReason ? (
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 col-span-2">
                <span className="text-red-700 block text-[11px]">سبب الوفاة وتاريخها:</span>
                <span className="font-bold text-red-900">
                  {animal.deathReason} · {formatDateArabic(animal.deathDate || '')}
                </span>
              </div>
            ) : null}
          </div>

          {/* Notes */}
          {animal.notes && (
            <div className="p-3 rounded-xl bg-stone-50 border border-stone-200 text-xs">
              <span className="text-stone-400 block text-[11px] font-semibold mb-0.5">ملاحظات:</span>
              <p className="text-stone-800 whitespace-pre-wrap">{animal.notes}</p>
            </div>
          )}

          {/* Health History */}
          <div className="space-y-2">
            <h3 className="font-bold text-stone-900 flex items-center gap-1.5 text-xs">
              <Activity size={14} className="text-emerald-700" />
              <span>السجل الصحي للحيوان ({healthRecords.length})</span>
            </h3>

            {healthRecords.length === 0 ? (
              <p className="text-stone-400 text-xs italic">لا توجد سجلات علاج مسجلة لهذا الرأس.</p>
            ) : (
              <div className="space-y-1.5">
                {healthRecords.map((h) => (
                  <div
                    key={h.id}
                    className="p-2.5 rounded-xl bg-white border border-stone-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-stone-900">{h.diseaseOrSymptom}</div>
                      <div className="text-[11px] text-stone-500">
                        {h.medication} · {formatDateArabic(h.treatmentDate)}
                      </div>
                    </div>
                    {h.costCentimes ? (
                      <span className="font-bold text-red-700 tabular-nums text-[11px]">
                        {formatDualCurrency(h.costCentimes, 'dzd')}
                      </span>
                    ) : null}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Reproduction History (if female or male) */}
          <div className="space-y-2">
            <h3 className="font-bold text-stone-900 flex items-center gap-1.5 text-xs">
              <Heart size={14} className="text-pink-600" />
              <span>سجل التلقيح والولادات ({breedings.length})</span>
            </h3>

            {breedings.length === 0 ? (
              <p className="text-stone-400 text-xs italic">لا توجد عمليات تلقيح أو ولادات مسجلة.</p>
            ) : (
              <div className="space-y-1.5">
                {breedings.map((b) => (
                  <div
                    key={b.id}
                    className="p-2.5 rounded-xl bg-white border border-stone-200 flex items-center justify-between text-xs"
                  >
                    <div>
                      <div className="font-bold text-stone-900">
                        {b.status === 'pregnant'
                          ? 'حامل قيد الانتظار'
                          : b.status === 'delivered'
                          ? `وضعت ${b.newbornCount} خروف`
                          : 'إجهاض'}
                      </div>
                      <div className="text-[11px] text-stone-500">
                        تلقيح: {formatDateArabic(b.matingDate)} | ولادة: {formatDateArabic(b.expectedLambingDate)}
                      </div>
                    </div>
                    <span
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        b.status === 'pregnant'
                          ? 'bg-amber-100 text-amber-800'
                          : b.status === 'delivered'
                          ? 'bg-emerald-100 text-emerald-800'
                          : 'bg-stone-100 text-stone-700'
                      }`}
                    >
                      {b.status === 'pregnant' ? 'حامل' : 'ولدت'}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Action Buttons: Mark as Sold or Mark as Dead (if in farm) */}
          {animal.status !== 'sold' && animal.status !== 'dead' && (
            <div className="pt-2 border-t border-stone-200 grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setShowSoldModal(true)}
                className="py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-98 transition text-xs"
              >
                <DollarSign size={15} />
                <span>تسجيل بيع الرأس</span>
              </button>

              <button
                type="button"
                onClick={() => setShowDeadModal(true)}
                className="py-2.5 px-3 rounded-xl bg-stone-700 hover:bg-stone-800 text-white font-bold flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-98 transition text-xs"
              >
                <Skull size={15} />
                <span>تسجيل نفوق / موت</span>
              </button>
            </div>
          )}
        </div>

        {/* Sub-modal: Record Sale */}
        {showSoldModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-sm w-full p-4 space-y-3">
              <h3 className="font-bold text-sm text-stone-900">تسجيل بيع الرأس ({animal.id})</h3>
              <p className="text-xs text-stone-500">
                سيتم تحويل حالة الحيوان إلى مباع وإضافة مبلغ البيع تلقائياً إلى المداخيل.
              </p>

              <CurrencyInput
                label="مبلغ البيع"
                centimesValue={salePriceCentimes}
                onChangeCentimes={setSalePriceCentimes}
                required
              />

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">تاريخ البيع</label>
                <input
                  type="date"
                  value={saleDate}
                  onChange={(e) => setSaleDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">ملاحظات البيع أو المشتري</label>
                <input
                  type="text"
                  value={saleNotes}
                  onChange={(e) => setSaleNotes(e.target.value)}
                  placeholder="اسم المشتري، رقم الهاتف..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowSoldModal(false)}
                  className="flex-1 py-2 rounded-xl bg-stone-100 text-stone-700 font-medium text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleConfirmSold}
                  className="flex-1 py-2 rounded-xl bg-emerald-700 text-white font-bold text-xs"
                >
                  تأكيد البيع
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Sub-modal: Record Death */}
        {showDeadModal && (
          <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs">
            <div className="bg-white rounded-2xl max-w-sm w-full p-4 space-y-3">
              <h3 className="font-bold text-sm text-stone-900">تسجيل نفوق الرأس ({animal.id})</h3>
              <p className="text-xs text-stone-500">
                سيتم تحديث السجل ولن يعاد استخدام الرقم التعريفي نهائياً.
              </p>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">تاريخ النفوق</label>
                <input
                  type="date"
                  value={deathDate}
                  onChange={(e) => setDeathDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">سبب النفوق أو المرض</label>
                <input
                  type="text"
                  value={deathReason}
                  onChange={(e) => setDeathReason(e.target.value)}
                  placeholder="مرض رئوي، حادث، تسمم معوي..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowDeadModal(false)}
                  className="flex-1 py-2 rounded-xl bg-stone-100 text-stone-700 font-medium text-xs"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDead}
                  className="flex-1 py-2 rounded-xl bg-red-700 text-white font-bold text-xs"
                >
                  تأكيد النفوق
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
