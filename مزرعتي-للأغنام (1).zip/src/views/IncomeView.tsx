import React, { useState } from 'react';
import {
  TrendingUp,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  X,
  Save,
  ArrowUpRight,
  DollarSign,
} from 'lucide-react';
import { IncomeCategory, IncomeRecord } from '../types';
import { SheepDB } from '../store/database';
import {
  centimesToDzd,
  formatCentimes,
  formatDateArabic,
  formatDzd,
  formatDualCurrency,
} from '../utils/formatters';
import { CurrencyInput } from '../components/CurrencyInput';

const INCOME_CATEGORIES: Record<IncomeCategory, { label: string; icon: string }> = {
  animal_sale: { label: 'بيع الأغنام والكباش', icon: '🐑' },
  lamb_sale: { label: 'بيع الخراف والمواليد', icon: '🐏' },
  wool_milk: { label: 'بيع الصوف أو الحليب', icon: '🧶' },
  manure: { label: 'بيع السماد العضوي (الغبار)', icon: '🌱' },
  other: { label: 'مداخيل أخرى', icon: '💰' },
};

export const IncomeView: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIncome, setEditingIncome] = useState<IncomeRecord | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Form
  const [category, setCategory] = useState<IncomeCategory>('animal_sale');
  const [title, setTitle] = useState('');
  const [amountCentimes, setAmountCentimes] = useState(0);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const incomeList = SheepDB.getIncome();
  const finance = SheepDB.getFinancialSummary();

  const handleOpenAdd = () => {
    setEditingIncome(null);
    setCategory('animal_sale');
    setTitle('بيع خروف');
    setAmountCentimes(0);
    setDate(new Date().toISOString().split('T')[0]);
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (inc: IncomeRecord) => {
    setEditingIncome(inc);
    setCategory(inc.category);
    setTitle(inc.title);
    setAmountCentimes(inc.amountCentimes);
    setDate(inc.date);
    setNotes(inc.notes || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || amountCentimes <= 0) {
      alert('يرجى ملء بيان المدخول والمبلغ');
      return;
    }

    if (editingIncome) {
      SheepDB.updateIncome({
        ...editingIncome,
        category,
        title,
        amountCentimes,
        amountDzd: centimesToDzd(amountCentimes),
        date,
        notes,
      });
    } else {
      SheepDB.addIncome({
        category,
        title,
        amountCentimes,
        amountDzd: centimesToDzd(amountCentimes),
        inputCurrency: 'centimes',
        date,
        notes,
      });
    }

    setIsModalOpen(false);
    setEditingIncome(null);
    setRefreshKey((k) => k + 1);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المدخول؟')) {
      SheepDB.deleteIncome(id);
      setRefreshKey((k) => k + 1);
    }
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Income Total Summary */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-xs flex items-center justify-between">
        <div className="space-y-0.5">
          <div className="text-xs text-stone-500 font-semibold flex items-center gap-1">
            <ArrowUpRight size={14} className="text-emerald-600" />
            <span>إجمالي المداخيل والمبيعات:</span>
          </div>
          <div className="text-xl font-black text-emerald-700 tabular-nums">
            {formatDzd(finance.totalIncomeCentimes)}
          </div>
          <div className="text-[11px] text-stone-500 tabular-nums">
            يعادل: {formatCentimes(finance.totalIncomeCentimes)}
          </div>
        </div>

        <div className="text-left bg-emerald-50 p-2.5 rounded-xl border border-emerald-200 text-xs">
          <span className="text-emerald-700 block text-[10px]">صافي الربح / الخسارة:</span>
          <span
            className={`font-extrabold tabular-nums ${
              finance.netProfitCentimes >= 0 ? 'text-emerald-800' : 'text-stone-700'
            }`}
          >
            {formatDzd(finance.netProfitCentimes)}
          </span>
        </div>
      </div>

      {/* Income Records List */}
      {incomeList.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-xs space-y-2">
          <TrendingUp size={32} className="text-stone-300 mx-auto" />
          <p className="text-xs font-bold text-stone-700">لا توجد مداخيل مسجلة حتى الآن</p>
          <p className="text-[11px] text-stone-400">
            سجل مبيعات الأغنام، الخراف، الصوف، أو السماد لتتبع الأرباح وإضافتها لرأس المال.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {incomeList.map((inc) => {
            const catInfo = INCOME_CATEGORIES[inc.category] || INCOME_CATEGORIES.other;

            return (
              <div
                key={inc.id}
                className="bg-white rounded-2xl p-3.5 border border-stone-200/80 shadow-xs hover:border-emerald-300 transition flex items-center justify-between gap-3"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center text-lg shrink-0">
                    <span>{catInfo.icon}</span>
                  </div>

                  <div className="min-w-0">
                    <h3 className="font-bold text-stone-900 text-xs truncate">{inc.title}</h3>
                    <div className="text-[11px] text-stone-500 flex items-center gap-1.5 mt-0.5">
                      <span className="font-medium text-emerald-800">{catInfo.label}</span>
                      <span>·</span>
                      <span>{formatDateArabic(inc.date)}</span>
                    </div>
                    {inc.notes && (
                      <p className="text-[10px] text-stone-400 truncate mt-0.5">{inc.notes}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-left">
                    <div className="font-black text-emerald-700 text-sm tabular-nums">
                      {formatDzd(inc.amountCentimes)}
                    </div>
                    <div className="text-[10px] text-stone-400 tabular-nums">
                      {formatCentimes(inc.amountCentimes)}
                    </div>
                  </div>

                  <div className="flex flex-col gap-1 mr-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(inc)}
                      className="p-1 rounded text-stone-400 hover:text-stone-700 hover:bg-stone-100"
                    >
                      <Edit2 size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(inc.id)}
                      className="p-1 rounded text-stone-400 hover:text-red-600 hover:bg-red-50"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={handleOpenAdd}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-emerald-950/20 transition cursor-pointer"
      >
        <Plus size={18} />
        <span>تسجيل مدخول / مبيعات</span>
      </button>

      {/* Modal: Add/Edit Income */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-emerald-800 text-white">
              <h2 className="text-base font-bold">
                {editingIncome ? 'تعديل بيانات المدخول' : 'تسجيل مدخول جديد'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-3.5 text-xs overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">نوع المدخول</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as IncomeCategory)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                >
                  {Object.entries(INCOME_CATEGORIES).map(([key, info]) => (
                    <option key={key} value={key}>
                      {info.icon} {info.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  بيان المدخول (الوصف) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: بيع خروف عيد، بيع صوف الربيع..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  required
                />
              </div>

              {/* Currency input */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <CurrencyInput
                  label="المبلغ المحصل"
                  centimesValue={amountCentimes}
                  onChangeCentimes={setAmountCentimes}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ التحصيل</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات إضافية</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="المشتري، طريقة الدفع..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>{editingIncome ? 'حفظ التعديلات' : 'تسجيل المدخول وإضافته لرأس المال'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
