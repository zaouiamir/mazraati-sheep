import React, { useState } from 'react';
import { Wheat, Plus, Calculator, Package, DollarSign, Trash2, X, Save, AlertCircle } from 'lucide-react';
import { FeedItem, FeedType, FeedUnit, TargetGroup } from '../types';
import { SheepDB } from '../store/database';
import { formatDualCurrency, formatNumber, formatDzd, formatCentimes } from '../utils/formatters';
import { CurrencyInput } from '../components/CurrencyInput';

export const FeedingView: React.FC = () => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingFeed, setEditingFeed] = useState<FeedItem | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Form states
  const [feedType, setFeedType] = useState<FeedType>('barley');
  const [name, setName] = useState('شعير حبوب');
  const [dailyRationGrams, setDailyRationGrams] = useState(400);
  const [targetGroup, setTargetGroup] = useState<TargetGroup>('all');
  const [stockQuantityKg, setStockQuantityKg] = useState(500);
  const [pricePerUnitCentimes, setPricePerUnitCentimes] = useState(450_000);
  const [unitType, setUnitType] = useState<FeedUnit>('quintal');
  const [unitWeightKg, setUnitWeightKg] = useState(100);
  const [notes, setNotes] = useState('');

  const feeds = SheepDB.getFeeds();
  const animals = SheepDB.getAnimals().filter((a) => a.status !== 'sold' && a.status !== 'dead');
  const totalAnimals = animals.length;

  // Consumption and Cost calculations
  const feedCalculations = feeds.map((feed) => {
    // Number of animals eating this feed
    let eligibleCount = totalAnimals;
    if (feed.targetGroup === 'females') {
      eligibleCount = animals.filter((a) => a.sex === 'female').length;
    } else if (feed.targetGroup === 'males') {
      eligibleCount = animals.filter((a) => a.sex === 'male').length;
    }

    // Daily consumption for flock (kg)
    const dailyFlockKg = (eligibleCount * feed.dailyRationGrams) / 1000;
    // Monthly consumption (kg)
    const monthlyFlockKg = dailyFlockKg * 30;

    // Price per kg in centimes
    const effectiveUnitWeight = feed.unitWeightKg > 0 ? feed.unitWeightKg : 100;
    const pricePerKgCentimes = feed.pricePerUnitCentimes / effectiveUnitWeight;

    // Daily & Monthly cost
    const dailyCostCentimes = dailyFlockKg * pricePerKgCentimes;
    const monthlyCostCentimes = monthlyFlockKg * pricePerKgCentimes;

    // Days of stock remaining
    const daysStockRemaining = dailyFlockKg > 0 ? Math.floor(feed.stockQuantityKg / dailyFlockKg) : 999;

    return {
      feed,
      eligibleCount,
      dailyFlockKg,
      monthlyFlockKg,
      pricePerKgCentimes,
      dailyCostCentimes,
      monthlyCostCentimes,
      daysStockRemaining,
    };
  });

  const totalDailyCostCentimes = feedCalculations.reduce((sum, item) => sum + item.dailyCostCentimes, 0);
  const totalMonthlyCostCentimes = totalDailyCostCentimes * 30;

  const handleOpenEdit = (feed: FeedItem) => {
    setEditingFeed(feed);
    setFeedType(feed.feedType);
    setName(feed.name);
    setDailyRationGrams(feed.dailyRationGrams);
    setTargetGroup(feed.targetGroup);
    setStockQuantityKg(feed.stockQuantityKg);
    setPricePerUnitCentimes(feed.pricePerUnitCentimes);
    setUnitType(feed.unitType);
    setUnitWeightKg(feed.unitWeightKg);
    setNotes(feed.notes || '');
    setIsAddModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingFeed) {
      SheepDB.updateFeed({
        ...editingFeed,
        feedType,
        name,
        dailyRationGrams,
        targetGroup,
        stockQuantityKg,
        pricePerUnitCentimes,
        unitType,
        unitWeightKg,
        notes,
      });
    } else {
      SheepDB.addFeed({
        feedType,
        name,
        dailyRationGrams,
        targetGroup,
        stockQuantityKg,
        pricePerUnitCentimes,
        unitType,
        unitWeightKg,
        notes,
      });
    }

    setIsAddModalOpen(false);
    setEditingFeed(null);
    setRefreshKey((k) => k + 1);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا العلف؟')) {
      SheepDB.deleteFeed(id);
      setRefreshKey((k) => k + 1);
    }
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Feed Cost Overview Hero Card */}
      <div className="bg-gradient-to-br from-[#2d6a4f] to-[#1b4332] rounded-2xl p-4 text-white shadow-md space-y-3">
        <div className="flex items-center justify-between text-emerald-200 text-xs font-semibold">
          <span className="flex items-center gap-1.5">
            <Calculator size={16} />
            <span>تكلفة تغذية القطيع الحالي ({totalAnimals} رأس)</span>
          </span>
          <span className="bg-emerald-900/60 px-2 py-0.5 rounded-full text-[11px]">
            محسوب يومياً وشهرياً
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-center">
          <div className="p-2.5 rounded-xl bg-black/20 border border-white/10">
            <div className="text-[11px] text-emerald-200">التكلفة اليومية للقطيع</div>
            <div className="text-lg font-black text-white tabular-nums mt-0.5">
              {formatDzd(totalDailyCostCentimes)}
            </div>
            <div className="text-[10px] text-emerald-300 tabular-nums">
              {formatCentimes(totalDailyCostCentimes)}
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-black/20 border border-white/10">
            <div className="text-[11px] text-emerald-200">التكلفة الشهرية التقديرية</div>
            <div className="text-lg font-black text-emerald-300 tabular-nums mt-0.5">
              {formatDzd(totalMonthlyCostCentimes)}
            </div>
            <div className="text-[10px] text-emerald-300 tabular-nums">
              {formatCentimes(totalMonthlyCostCentimes)}
            </div>
          </div>
        </div>
      </div>

      {/* Feed Inventory & Daily Rations */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
            <Wheat size={16} className="text-emerald-700" />
            <span>الأعلاف والمقادير اليومية والمخزون</span>
          </h2>
          <span className="text-[11px] text-stone-500 font-medium">{feeds.length} أنواع</span>
        </div>

        <div className="space-y-3">
          {feedCalculations.map(
            ({
              feed,
              eligibleCount,
              dailyFlockKg,
              monthlyFlockKg,
              dailyCostCentimes,
              monthlyCostCentimes,
              daysStockRemaining,
            }) => (
              <div
                key={feed.id}
                className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-xs space-y-3"
              >
                {/* Header */}
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="font-bold text-stone-900 text-sm flex items-center gap-1.5">
                      <span>{feed.name}</span>
                      <span className="text-[10px] font-semibold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-md">
                        {feed.feedType === 'barley'
                          ? 'شعير'
                          : feed.feedType === 'bran'
                          ? 'نخالة'
                          : feed.feedType === 'corn'
                          ? 'ذرة'
                          : feed.feedType === 'hay'
                          ? 'قرط / كلأ'
                          : feed.feedType === 'straw'
                          ? 'تبن'
                          : 'علف مركب'}
                      </span>
                    </h3>
                    <p className="text-[11px] text-stone-500">
                      الفئة المستهدفة: {feed.targetGroup === 'all' ? 'كامل القطيع' : feed.targetGroup === 'females' ? 'النعاج فقط' : 'الكباش فقط'} ({eligibleCount} رأس)
                    </p>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(feed)}
                      className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 px-2 py-1 rounded-lg hover:bg-emerald-50"
                    >
                      تعديل
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(feed.id)}
                      className="p-1 text-stone-400 hover:text-red-500"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Ration & Consumption Details */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs bg-stone-50 p-3 rounded-xl border border-stone-200/60">
                  <div>
                    <span className="text-stone-400 block text-[10px]">الوجبة اليومية للرأس:</span>
                    <span className="font-bold text-stone-900 tabular-nums">
                      {feed.dailyRationGrams} غرام
                    </span>
                  </div>

                  <div>
                    <span className="text-stone-400 block text-[10px]">استهلاك القطيع اليومي:</span>
                    <span className="font-bold text-stone-900 tabular-nums">
                      {formatNumber(dailyFlockKg)} كغ/يوم
                    </span>
                  </div>

                  <div>
                    <span className="text-stone-400 block text-[10px]">المخزون المتوفر:</span>
                    <span className="font-bold text-emerald-800 tabular-nums">
                      {formatNumber(feed.stockQuantityKg)} كغ
                    </span>
                  </div>

                  <div>
                    <span className="text-stone-400 block text-[10px]">كفاية المخزون التقديرية:</span>
                    <span
                      className={`font-bold tabular-nums ${
                        daysStockRemaining <= 10 ? 'text-red-600' : 'text-emerald-700'
                      }`}
                    >
                      {daysStockRemaining > 300 ? 'وفرة كافية' : `تكفي ${daysStockRemaining} يوم`}
                    </span>
                  </div>
                </div>

                {/* Cost Strip */}
                <div className="flex items-center justify-between text-xs pt-1 border-t border-stone-100">
                  <div className="text-stone-500">
                    سعر الشراء: <span className="font-bold text-stone-800">{formatDualCurrency(feed.pricePerUnitCentimes, 'dzd')}</span> / {feed.unitType === 'quintal' ? 'قنطار' : feed.unitType === 'bale' ? 'بالة' : 'كيس'}
                  </div>

                  <div className="text-left font-bold text-emerald-900 tabular-nums">
                    {formatDzd(dailyCostCentimes)} <span className="text-[10px] text-stone-500">يومياً</span>
                  </div>
                </div>
              </div>
            )
          )}
        </div>
      </div>

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={() => {
          setEditingFeed(null);
          setIsAddModalOpen(true);
        }}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-emerald-950/20 transition cursor-pointer"
      >
        <Plus size={18} />
        <span>إضافة مادة علفية</span>
      </button>

      {/* Add / Edit Feed Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
              <h2 className="text-base font-bold">
                {editingFeed ? 'تعديل بيانات العلف' : 'إضافة نوع علف جديد'}
              </h2>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-3.5 text-xs overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">نوع المادة العلفية</label>
                <select
                  value={feedType}
                  onChange={(e) => {
                    const t = e.target.value as FeedType;
                    setFeedType(t);
                    if (!editingFeed) {
                      if (t === 'barley') setName('شعير حبوب');
                      else if (t === 'bran') setName('نخالة قمح');
                      else if (t === 'hay') setName('قرط فصة وكلأ');
                      else if (t === 'straw') setName('تبن قمح ذهبي');
                      else if (t === 'mixed') setName('علف مركب (سيكاليم)');
                      else if (t === 'corn') setName('ذرة صفراء مجروشة');
                    }
                  }}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                >
                  <option value="barley">شعير (حبوب)</option>
                  <option value="bran">نخالة</option>
                  <option value="corn">ذرة</option>
                  <option value="hay">قرط / كلأ أخضر مجفف</option>
                  <option value="straw">تبن</option>
                  <option value="mixed">علف مركب (سيكاليم)</option>
                  <option value="other">أخرى</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">الاسم التجاري أو الوصف</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الوجبة اليومية للرأس (غرام) <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    min="10"
                    max="5000"
                    value={dailyRationGrams}
                    onChange={(e) => setDailyRationGrams(parseInt(e.target.value) || 0)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white tabular-nums"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الفئة المستهدفة</label>
                  <select
                    value={targetGroup}
                    onChange={(e) => setTargetGroup(e.target.value as TargetGroup)}
                    className="w-full h-10 px-2 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  >
                    <option value="all">كامل القطيع</option>
                    <option value="females">النعاج فقط</option>
                    <option value="males">الكباش فقط</option>
                    <option value="pregnant">النعاج الحوامل فقط</option>
                    <option value="lambs">الخراف والمواليد</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    المخزون المتوفر في المستودع (كغ)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={stockQuantityKg}
                    onChange={(e) => setStockQuantityKg(parseFloat(e.target.value) || 0)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white tabular-nums"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">وحدة الشراء</label>
                  <select
                    value={unitType}
                    onChange={(e) => {
                      const u = e.target.value as FeedUnit;
                      setUnitType(u);
                      if (u === 'quintal') setUnitWeightKg(100);
                      else if (u === 'bale') setUnitWeightKg(20);
                      else if (u === 'bag') setUnitWeightKg(50);
                      else setUnitWeightKg(1);
                    }}
                    className="w-full h-10 px-2 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  >
                    <option value="quintal">قنطار (100 كغ)</option>
                    <option value="bale">بالة (حوالي 20 كغ)</option>
                    <option value="bag">كيس (50 كغ)</option>
                    <option value="kg">كيلوغرام فردي</option>
                  </select>
                </div>
              </div>

              <CurrencyInput
                label="سعر شراء الوحدة (للقنطار أو البالة أو الكيس)"
                centimesValue={pricePerUnitCentimes}
                onChangeCentimes={setPricePerUnitCentimes}
                required
              />

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="مورد العلف، مكان التخزين..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>{editingFeed ? 'حفظ التعديلات' : 'إضافة العلف إلى السجل'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
