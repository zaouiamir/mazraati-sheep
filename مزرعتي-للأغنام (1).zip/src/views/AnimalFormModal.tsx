import React, { useState, useEffect } from 'react';
import { X, Save } from 'lucide-react';
import { Animal, AnimalSex, AnimalSource, AnimalStatus } from '../types';
import { SheepDB } from '../store/database';
import { PhotoPicker } from '../components/PhotoPicker';
import { CurrencyInput } from '../components/CurrencyInput';
import { calculateAgeArabic } from '../utils/formatters';

interface AnimalFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  editingAnimal?: Animal | null;
}

export const AnimalFormModal: React.FC<AnimalFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingAnimal,
}) => {
  const [sex, setSex] = useState<AnimalSex>('female');
  const [birthDate, setBirthDate] = useState<string>('2024-05-01');
  const [source, setSource] = useState<AnimalSource>('purchase');
  const [color, setColor] = useState<string>('بيضاء');
  const [markings, setMarkings] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [motherId, setMotherId] = useState<string>('');
  const [fatherId, setFatherId] = useState<string>('');
  const [purchasePriceCentimes, setPurchasePriceCentimes] = useState<number>(0);
  const [photo, setPhoto] = useState<string | undefined>(undefined);
  const [status, setStatus] = useState<AnimalStatus>('healthy');

  // Load existing animals for mother/father selector
  const allAnimals = SheepDB.getAnimals();
  const females = allAnimals.filter((a) => a.sex === 'female');
  const males = allAnimals.filter((a) => a.sex === 'male');

  useEffect(() => {
    if (editingAnimal) {
      setSex(editingAnimal.sex);
      setBirthDate(editingAnimal.birthDate);
      setSource(editingAnimal.source);
      setColor(editingAnimal.color);
      setMarkings(editingAnimal.markings || '');
      setNotes(editingAnimal.notes || '');
      setMotherId(editingAnimal.motherId || '');
      setFatherId(editingAnimal.fatherId || '');
      setPurchasePriceCentimes(editingAnimal.purchasePriceCentimes || 0);
      setPhoto(editingAnimal.photo);
      setStatus(editingAnimal.status);
    } else {
      // Default for new
      setSex('female');
      setBirthDate(new Date().toISOString().split('T')[0]);
      setSource('purchase');
      setColor('بيضاء');
      setMarkings('');
      setNotes('');
      setMotherId('');
      setFatherId('');
      setPurchasePriceCentimes(0);
      setPhoto(undefined);
      setStatus('healthy');
    }
  }, [editingAnimal, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (editingAnimal) {
      // Update
      SheepDB.updateAnimal({
        ...editingAnimal,
        sex,
        birthDate,
        source,
        color,
        markings,
        notes,
        status,
        motherId: source === 'farm_born' ? motherId || null : null,
        fatherId: source === 'farm_born' ? fatherId || null : null,
        purchasePriceCentimes: source === 'purchase' ? purchasePriceCentimes : undefined,
        photo,
      });
    } else {
      // Add new - ID will be generated automatically (N .. or K ..)
      SheepDB.addAnimal({
        sex,
        birthDate,
        source,
        color,
        markings,
        notes,
        status,
        motherId: source === 'farm_born' ? motherId || null : null,
        fatherId: source === 'farm_born' ? fatherId || null : null,
        purchasePriceCentimes: source === 'purchase' && purchasePriceCentimes > 0 ? purchasePriceCentimes : undefined,
        photo,
      });
    }

    onSave();
    onClose();
  };

  const currentAge = calculateAgeArabic(birthDate);

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
          <div>
            <h2 className="text-base font-bold">
              {editingAnimal ? `تعديل بيانات الرأس (${editingAnimal.id})` : 'تسجيل رأس غنم جديد'}
            </h2>
            <p className="text-[11px] text-emerald-200">
              {editingAnimal
                ? 'تحديث معلومات السجل والبيانات'
                : 'سيتم توليد الرقم التعريفي تلقائياً (إناث: N.. / ذكور: K..)'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-white/10"
          >
            <X size={20} />
          </button>
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-5 space-y-4 text-xs">
          {/* Sex Selection */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1.5">
              الجنس (تحديد نوع الرقم التعريفي) <span className="text-red-500">*</span>
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSex('female')}
                disabled={!!editingAnimal}
                className={`py-2.5 px-3 rounded-xl border text-center font-bold text-xs transition cursor-pointer ${
                  sex === 'female'
                    ? 'bg-pink-50 border-pink-500 text-pink-700 shadow-xs'
                    : 'bg-stone-50 border-stone-200 text-stone-600'
                } ${editingAnimal ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                نعجة / أنثى (رمز N)
              </button>
              <button
                type="button"
                onClick={() => setSex('male')}
                disabled={!!editingAnimal}
                className={`py-2.5 px-3 rounded-xl border text-center font-bold text-xs transition cursor-pointer ${
                  sex === 'male'
                    ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-xs'
                    : 'bg-stone-50 border-stone-200 text-stone-600'
                } ${editingAnimal ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                كبش / ذكر (رمز K)
              </button>
            </div>
            {editingAnimal && (
              <p className="text-[10px] text-stone-400 mt-1">لا يمكن تغيير الجنس بعد إنشاء الرقم التعريفي للحفاظ على تسلسل السجل.</p>
            )}
          </div>

          {/* Source Selection */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1.5">مصدر الحيوان</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSource('purchase')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition cursor-pointer ${
                  source === 'purchase'
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-800 font-bold'
                    : 'bg-stone-50 border-stone-200 text-stone-600'
                }`}
              >
                شراء من السوق/مزرعة
              </button>
              <button
                type="button"
                onClick={() => setSource('farm_born')}
                className={`py-2 px-3 rounded-xl border text-center font-medium transition cursor-pointer ${
                  source === 'farm_born'
                    ? 'bg-emerald-50 border-emerald-600 text-emerald-800 font-bold'
                    : 'bg-stone-50 border-stone-200 text-stone-600'
                }`}
              >
                ولادة في المزرعة
              </button>
            </div>
          </div>

          {/* Mother and Father (if farm born) */}
          {source === 'farm_born' && (
            <div className="grid grid-cols-2 gap-3 p-3 bg-amber-50/50 rounded-xl border border-amber-200/60">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  النعجة الأم
                </label>
                <select
                  value={motherId}
                  onChange={(e) => setMotherId(e.target.value)}
                  className="w-full h-10 px-2 rounded-xl border border-stone-300 bg-white text-xs"
                >
                  <option value="">اختر الأم من السجل...</option>
                  {females.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.id} ({f.color})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  الكبش الأب (الفحل)
                </label>
                <select
                  value={fatherId}
                  onChange={(e) => setFatherId(e.target.value)}
                  className="w-full h-10 px-2 rounded-xl border border-stone-300 bg-white text-xs"
                >
                  <option value="">اختر الأب (اختياري)...</option>
                  {males.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.id} ({m.color})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Purchase price (if purchased) */}
          {source === 'purchase' && (
            <div className="p-3 bg-stone-50 rounded-xl border border-stone-200/60">
              <CurrencyInput
                label="سعر الشراء (اختياري - يضاف للمصاريف)"
                centimesValue={purchasePriceCentimes}
                onChangeCentimes={setPurchasePriceCentimes}
              />
            </div>
          )}

          {/* Birth Date & Calculated Age */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                تاريخ الميلاد <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">
                العمر المحسوب تلقائياً
              </label>
              <div className="h-10 px-3 rounded-xl border border-emerald-200 bg-emerald-50/50 flex items-center font-bold text-emerald-800 text-xs">
                {currentAge}
              </div>
            </div>
          </div>

          {/* Color & Markings */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">اللون</label>
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="مثال: بيضاء، بيضاء برأس أشقر، سمراء"
                className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1">العلامات المميزة</label>
              <input
                type="text"
                value={markings}
                onChange={(e) => setMarkings(e.target.value)}
                placeholder="حلقة أذن، قرون، نقطة صوف..."
                className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
              />
            </div>
          </div>

          {/* Status (healthy, pregnant, sick, sold, dead) */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">الحالة الصحية والتواجد</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as AnimalStatus)}
              className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
            >
              <option value="healthy">سليم / بصحة جيدة</option>
              <option value="pregnant">حامل (نعجة)</option>
              <option value="sick">مريض / قيد العلاج</option>
              <option value="sold">تم البيع</option>
              <option value="dead">نافق / ميت</option>
            </select>
          </div>

          {/* Photo Upload */}
          <PhotoPicker
            value={photo}
            onChange={setPhoto}
            label="صورة الحيوان (كاميرا أو معرض)"
          />

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات إضافية</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              placeholder="سلالة، ملاحظات صحية أو إنتاجية..."
              className="w-full p-2.5 rounded-xl border border-stone-300 text-xs bg-white"
            />
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md active:scale-98 transition cursor-pointer"
            >
              <Save size={18} />
              <span>{editingAnimal ? 'حفظ التعديلات' : 'تسجيل الرأس في السجل'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
