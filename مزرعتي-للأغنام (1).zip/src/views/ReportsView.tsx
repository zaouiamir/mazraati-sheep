import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  PieChart,
  Layers,
  Printer,
  TrendingUp,
} from 'lucide-react';
import { SheepDB } from '../store/database';
import {
  formatDzd,
  formatCentimes,
  formatDualCurrency,
  formatDateArabic,
  formatNumber,
} from '../utils/formatters';

export const ReportsView: React.FC = () => {
  const finance = SheepDB.getFinancialSummary();
  const flock = SheepDB.getFlockSummary();
  const expenses = SheepDB.getExpenses();
  const income = SheepDB.getIncome();

  // Category breakdown
  const categoryTotals: Record<string, number> = {};
  expenses.forEach((e) => {
    categoryTotals[e.category] = (categoryTotals[e.category] || 0) + e.amountCentimes;
  });

  const categoryNames: Record<string, string> = {
    livestock: 'شراء المواشي',
    feed: 'الأعلاف المركزة',
    hay_straw: 'القرط والتبن',
    vet: 'العلاج والبيطرة',
    vaccine: 'التطعيمات واللقاحات',
    transport: 'النقل والمواصلات',
    equipment: 'المعدات والأدوات',
    other: 'مصاريف أخرى',
  };

  // Group expenses by month
  const monthlyExpenses: Record<string, { month: string; expenses: number; income: number }> = {};

  expenses.forEach((e) => {
    const monthKey = e.date.substring(0, 7); // YYYY-MM
    if (!monthlyExpenses[monthKey]) {
      monthlyExpenses[monthKey] = { month: monthKey, expenses: 0, income: 0 };
    }
    monthlyExpenses[monthKey].expenses += e.amountCentimes;
  });

  income.forEach((i) => {
    const monthKey = i.date.substring(0, 7);
    if (!monthlyExpenses[monthKey]) {
      monthlyExpenses[monthKey] = { month: monthKey, expenses: 0, income: 0 };
    }
    monthlyExpenses[monthKey].income += i.amountCentimes;
  });

  const sortedMonths = Object.values(monthlyExpenses).sort((a, b) => b.month.localeCompare(a.month));

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-4 pb-24 print:p-0">
      {/* Printable / View Header */}
      <div className="flex items-center justify-between px-1">
        <div>
          <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
            <BarChart3 size={18} className="text-emerald-700" />
            <span>التقرير المالي وكشوفات القطيع</span>
          </h2>
          <p className="text-xs text-stone-500">حسابات دقيقة لرأس المال والمصاريف والأرباح</p>
        </div>

        <button
          type="button"
          onClick={handlePrint}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white border border-stone-200 text-xs font-semibold text-stone-700 hover:bg-stone-50 shadow-xs cursor-pointer print:hidden"
        >
          <Printer size={15} />
          <span>طباعة التقرير</span>
        </button>
      </div>

      {/* Main Capital Balance Sheet */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs space-y-4">
        <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
          <Wallet size={15} className="text-emerald-700" />
          <span>الميزانية العامة للمزرعة (رأس المال الصافي)</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="p-3 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-[11px] text-stone-500 block">رأس المال الابتدائي:</span>
            <span className="font-extrabold text-stone-900 text-base tabular-nums">
              {formatDzd(finance.startingCapitalCentimes)}
            </span>
            <span className="text-[10px] text-stone-400 block mt-0.5 tabular-nums">
              (120 مليون سنتيم)
            </span>
          </div>

          <div className="p-3 rounded-xl bg-red-50/60 border border-red-200">
            <span className="text-[11px] text-red-600 block">إجمالي المصاريف:</span>
            <span className="font-extrabold text-red-700 text-base tabular-nums">
              {formatDzd(finance.totalExpensesCentimes)}
            </span>
            <span className="text-[10px] text-red-500 block mt-0.5 tabular-nums">
              {formatCentimes(finance.totalExpensesCentimes)}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200">
            <span className="text-[11px] text-emerald-600 block">إجمالي المداخيل:</span>
            <span className="font-extrabold text-emerald-700 text-base tabular-nums">
              {formatDzd(finance.totalIncomeCentimes)}
            </span>
            <span className="text-[10px] text-emerald-500 block mt-0.5 tabular-nums">
              {formatCentimes(finance.totalIncomeCentimes)}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-emerald-900 text-white shadow-xs">
            <span className="text-[11px] text-emerald-200 block">رأس المال المتبقي:</span>
            <span className="font-extrabold text-white text-base tabular-nums">
              {formatDzd(finance.remainingCapitalCentimes)}
            </span>
            <span className="text-[10px] text-emerald-300 block mt-0.5 tabular-nums">
              {formatCentimes(finance.remainingCapitalCentimes)}
            </span>
          </div>
        </div>
      </div>

      {/* Expenses Breakdown by Category */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
          <PieChart size={15} className="text-emerald-700" />
          <span>توزيع المصاريف حسب التصنيف</span>
        </h3>

        <div className="space-y-2">
          {Object.entries(categoryTotals)
            .sort((a, b) => b[1] - a[1])
            .map(([cat, totalCentimes]) => {
              const percentage =
                finance.totalExpensesCentimes > 0
                  ? Math.round((totalCentimes / finance.totalExpensesCentimes) * 100)
                  : 0;

              return (
                <div key={cat} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-800">
                      {categoryNames[cat] || cat}
                    </span>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-stone-900 tabular-nums">
                        {formatDzd(totalCentimes)}
                      </span>
                      <span className="text-[11px] text-stone-400 font-semibold tabular-nums w-8 text-left">
                        {percentage}%
                      </span>
                    </div>
                  </div>

                  {/* Visual Progress Bar */}
                  <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
                    <div
                      className="h-full rounded-full bg-emerald-600 transition-all duration-300"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
        </div>
      </div>

      {/* Monthly Cashflow Table */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
          <Calendar size={15} className="text-emerald-700" />
          <span>حركة الصندوق الشهرية</span>
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead>
              <tr className="border-b border-stone-200 text-stone-400 text-[11px]">
                <th className="pb-2 font-semibold">الشهر</th>
                <th className="pb-2 font-semibold">المصاريف</th>
                <th className="pb-2 font-semibold">المداخيل</th>
                <th className="pb-2 font-semibold text-left">الفرق الشهري</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {sortedMonths.map((m) => {
                const diff = m.income - m.expenses;
                return (
                  <tr key={m.month} className="hover:bg-stone-50/50">
                    <td className="py-2.5 font-bold text-stone-900 tabular-nums">{m.month}</td>
                    <td className="py-2.5 text-red-700 font-semibold tabular-nums">
                      {formatDzd(m.expenses)}
                    </td>
                    <td className="py-2.5 text-emerald-700 font-semibold tabular-nums">
                      {formatDzd(m.income)}
                    </td>
                    <td
                      className={`py-2.5 font-bold tabular-nums text-left ${
                        diff >= 0 ? 'text-emerald-800' : 'text-stone-600'
                      }`}
                    >
                      {formatDzd(diff)}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Flock Demographics Report */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs space-y-3">
        <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
          <Layers size={15} className="text-emerald-700" />
          <span>التقرير الديموغرافي للقطيع</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
          <div className="p-3 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-stone-500 block text-[11px]">الأغنام الحالية:</span>
            <span className="text-lg font-black text-stone-900 tabular-nums">
              {flock.totalPresent} رأس
            </span>
          </div>

          <div className="p-3 rounded-xl bg-pink-50 border border-pink-200">
            <span className="text-pink-700 block text-[11px]">إناث (نعاج N):</span>
            <span className="text-lg font-black text-pink-900 tabular-nums">
              {flock.femalesCount} رأس
            </span>
          </div>

          <div className="p-3 rounded-xl bg-blue-50 border border-blue-200">
            <span className="text-blue-700 block text-[11px]">ذكور (كباش K):</span>
            <span className="text-lg font-black text-blue-900 tabular-nums">
              {flock.malesCount} رأس
            </span>
          </div>

          <div className="p-3 rounded-xl bg-amber-50 border border-amber-200">
            <span className="text-amber-800 block text-[11px]">حوامل وولادات متوقعة:</span>
            <span className="text-lg font-black text-amber-900 tabular-nums">
              {flock.pregnantEwesCount} رأس
            </span>
          </div>

          <div className="p-3 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-stone-500 block text-[11px]">الأغنام المباعة:</span>
            <span className="text-lg font-black text-stone-900 tabular-nums">
              {flock.soldCount} رأس
            </span>
          </div>

          <div className="p-3 rounded-xl bg-red-50 border border-red-200">
            <span className="text-red-700 block text-[11px]">الرؤوس النافقة:</span>
            <span className="text-lg font-black text-red-900 tabular-nums">
              {flock.deadCount} رأس
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
