import React, { useState } from 'react';
import { Activity, Plus, Calendar, ShieldCheck, Stethoscope, Trash2, X, Save, Bell } from 'lucide-react';
import { HealthRecord, HealthRecordType } from '../types';
import { SheepDB } from '../store/database';
import { formatDateArabic, formatDualCurrency } from '../utils/formatters';
import { CurrencyInput } from '../components/CurrencyInput';
import { PhotoPicker } from '../components/PhotoPicker';

export const HealthView: React.FC = () => {
  const [filterType, setFilterType] = useState<'all' | HealthRecordType>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  // Form fields
  const [animalId, setAnimalId] = useState('all');
  const [type, setType] = useState<HealthRecordType>('treatment');
  const [diseaseOrSymptom, setDiseaseOrSymptom] = useState('');
  const [vetName, setVetName] = useState('');
  const [medication, setMedication] = useState('');
  const [dosage, setDosage] = useState('');
  const [treatmentDate, setTreatmentDate] = useState(new Date().toISOString().split('T')[0]);
  const [nextReminderDate, setNextReminderDate] = useState('');
  const [costCentimes, setCostCentimes] = useState(0);
  const [recordAsExpense, setRecordAsExpense] = useState(true);
  const [notes, setNotes] = useState('');
  const [photo, setPhoto] = useState<string | undefined>(undefined);

  const healthRecords = SheepDB.getHealthRecords();
  const animals = SheepDB.getAnimals().filter((a) => a.status !== 'sold' && a.status !== 'dead');

  const filtered = healthRecords.filter((h) => {
    if (filterType === 'all') return true;
    return h.type === filterType;
  });

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!diseaseOrSymptom || !medication) {
      alert('يرجى ملء اسم المرض/العرض والدواء المستخدم');
      return;
    }

    SheepDB.addHealthRecord({
      animalId,
      type,
      diseaseOrSymptom,
      vetName,
      medication,
      dosage,
      treatmentDate,
      nextReminderDate: nextReminderDate || null,
      costCentimes: costCentimes > 0 ? costCentimes : undefined,
      recordAsExpense,
      notes,
      photo,
    });

    setIsAddModalOpen(false);
    // Reset form
    setDiseaseOrSymptom('');
    setVetName('');
    setMedication('');
    setDosage('');
    setCostCentimes(0);
    setNextReminderDate('');
    setNotes('');
    setPhoto(undefined);
    setRefreshKey((k) => k + 1);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا السجل الصحي؟')) {
      SheepDB.deleteHealthRecord(id);
      setRefreshKey((k) => k + 1);
    }
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Type Filter Tabs */}
      <div className="space-y-2 sticky top-[60px] z-20 bg-stone-50 pt-1 pb-2">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            type="button"
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterType === 'all'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            جميع السجلات ({healthRecords.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('treatment')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterType === 'treatment'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            العلاجات ({healthRecords.filter((h) => h.type === 'treatment').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('vaccination')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterType === 'vaccination'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            التطعيمات واللقاحات ({healthRecords.filter((h) => h.type === 'vaccination').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('vet_visit')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterType === 'vet_visit'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            الزيارات البيطرية ({healthRecords.filter((h) => h.type === 'vet_visit').length})
          </button>
        </div>
      </div>

      {/* Health Records List */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-xs space-y-2">
          <Activity size={32} className="text-stone-300 mx-auto" />
          <p className="text-xs font-bold text-stone-700">لا توجد سجلات صحية مسجلة</p>
          <p className="text-[11px] text-stone-400">سجل التطعيمات والزيارات البيطرية والعلاجات لحماية القطيع.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {filtered.map((rec) => (
            <div
              key={rec.id}
              className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-xs space-y-2 relative"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${
                      rec.type === 'vaccination'
                        ? 'bg-blue-100 text-blue-800'
                        : rec.type === 'treatment'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-purple-100 text-purple-800'
                    }`}
                  >
                    {rec.type === 'vaccination' ? (
                      <ShieldCheck size={18} />
                    ) : (
                      <Stethoscope size={18} />
                    )}
                  </div>
                  <div>
                    <h3 className="font-bold text-stone-900 text-xs">{rec.diseaseOrSymptom}</h3>
                    <div className="text-[11px] text-stone-500 flex items-center gap-1.5">
                      <span className="font-semibold text-emerald-800">
                        {rec.animalId === 'all' ? 'كامل القطيع' : `رقم الرأس: ${rec.animalId}`}
                      </span>
                      <span>·</span>
                      <span>{formatDateArabic(rec.treatmentDate)}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  {rec.costCentimes ? (
                    <span className="text-xs font-bold text-red-700 tabular-nums bg-red-50 px-2 py-0.5 rounded-lg border border-red-100">
                      {formatDualCurrency(rec.costCentimes, 'dzd')}
                    </span>
                  ) : null}
                  <button
                    type="button"
                    onClick={() => handleDelete(rec.id)}
                    className="p-1 rounded-lg text-stone-400 hover:text-red-500 transition"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              {/* Medication and Vet info */}
              <div className="grid grid-cols-2 gap-2 text-[11px] p-2.5 rounded-xl bg-stone-50 border border-stone-200/60">
                <div>
                  <span className="text-stone-400 block text-[10px]">العلاج والدواء:</span>
                  <span className="font-bold text-stone-800">{rec.medication}</span>
                  {rec.dosage && <span className="text-stone-500"> ({rec.dosage})</span>}
                </div>
                <div>
                  <span className="text-stone-400 block text-[10px]">الطبيب البيطري:</span>
                  <span className="font-bold text-stone-800">{rec.vetName || 'طبيب محلي'}</span>
                </div>
              </div>

              {/* Next Reminder if set */}
              {rec.nextReminderDate && (
                <div className="flex items-center gap-1.5 text-[11px] text-amber-800 bg-amber-50 px-2.5 py-1.5 rounded-xl border border-amber-200 font-semibold">
                  <Bell size={13} className="text-amber-600 shrink-0" />
                  <span>موعد الجرعة أو التطعيم القادم: {formatDateArabic(rec.nextReminderDate)}</span>
                </div>
              )}

              {/* Notes */}
              {rec.notes && <p className="text-[11px] text-stone-600 pt-0.5">{rec.notes}</p>}
            </div>
          ))}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-emerald-950/20 transition cursor-pointer"
      >
        <Plus size={18} />
        <span>تسجيل علاج أو تطعيم</span>
      </button>

      {/* Add Health Record Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
              <h2 className="text-base font-bold">تسجيل فحص أو علاج بيطري</h2>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-3.5 text-xs overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  الرأس المعالج أو القطيع <span className="text-red-500">*</span>
                </label>
                <select
                  value={animalId}
                  onChange={(e) => setAnimalId(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                >
                  <option value="all">كامل القطيع (حملة جماعية)</option>
                  {animals.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.id} ({a.sex === 'female' ? 'نعجة' : 'كبش'} - {a.color})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">نوع الإجراء</label>
                <div className="grid grid-cols-3 gap-1.5">
                  {[
                    { id: 'treatment', label: 'علاج ودواء' },
                    { id: 'vaccination', label: 'تطعيم ولقاح' },
                    { id: 'vet_visit', label: 'كشف بيطري' },
                  ].map((t) => (
                    <button
                      key={t.id}
                      type="button"
                      onClick={() => setType(t.id as HealthRecordType)}
                      className={`py-2 px-2 rounded-xl text-center font-bold text-[11px] border cursor-pointer transition ${
                        type === t.id
                          ? 'bg-emerald-700 border-emerald-700 text-white shadow-xs'
                          : 'bg-stone-50 border-stone-200 text-stone-700'
                      }`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  المرض أو الأعراض أو اسم اللقاح <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={diseaseOrSymptom}
                  onChange={(e) => setDiseaseOrSymptom(e.target.value)}
                  placeholder="مثال: التهاب رئوي، جدري، طفيليات، لقاح التسمم المعوي..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    الدواء المستخدم <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    value={medication}
                    onChange={(e) => setMedication(e.target.value)}
                    placeholder="إيفوميك، بنسلين..."
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الجرعة / الطريقة</label>
                  <input
                    type="text"
                    value={dosage}
                    onChange={(e) => setDosage(e.target.value)}
                    placeholder="حقن، تجريع، 2 مل..."
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ العلاج</label>
                  <input
                    type="date"
                    value={treatmentDate}
                    onChange={(e) => setTreatmentDate(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الطبيب البيطري</label>
                  <input
                    type="text"
                    value={vetName}
                    onChange={(e) => setVetName(e.target.value)}
                    placeholder="اسم الطبيب أو العيادة..."
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                  />
                </div>
              </div>

              {/* Next Dose Reminder Date */}
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  موعد التذكير بالجرعة القادمة (اختياري)
                </label>
                <input
                  type="date"
                  value={nextReminderDate}
                  onChange={(e) => setNextReminderDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              {/* Cost in Centimes / DZD */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 space-y-2">
                <CurrencyInput
                  label="تكلفة العلاج أو الفحص البيطري"
                  centimesValue={costCentimes}
                  onChangeCentimes={setCostCentimes}
                />

                {costCentimes > 0 && (
                  <label className="flex items-center gap-2 pt-1 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={recordAsExpense}
                      onChange={(e) => setRecordAsExpense(e.target.checked)}
                      className="w-4 h-4 text-emerald-600 rounded"
                    />
                    <span className="text-xs font-bold text-stone-700">
                      تسجيل هذا المبلغ تلقائياً في قائمة المصاريف
                    </span>
                  </label>
                )}
              </div>

              <PhotoPicker value={photo} onChange={setPhoto} label="صورة الروشتة أو الحالة (اختياري)" />

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات إضافية</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="ملاحظات وتوصيات الطبيب..."
                  className="w-full p-2.5 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>حفظ السجل الصحي</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
