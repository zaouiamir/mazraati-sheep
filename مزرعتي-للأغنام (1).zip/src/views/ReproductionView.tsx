import React, { useState } from 'react';
import {
  Heart,
  Plus,
  Calendar,
  Baby,
  Clock,
  CheckCircle2,
  AlertCircle,
  X,
  Save,
  Trash2,
} from 'lucide-react';
import {
  BreedingRecord,
  GestationStatus,
  NewbornCondition,
  NewbornDetail,
  AnimalSex,
} from '../types';
import { SheepDB } from '../store/database';
import {
  calculateExpectedLambing,
  getDaysUntilLambing,
  formatDateArabic,
} from '../utils/formatters';
import { PhotoPicker } from '../components/PhotoPicker';

export const ReproductionView: React.FC = () => {
  const [filterStatus, setFilterStatus] = useState<'all' | GestationStatus>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [deliveryModalRecord, setDeliveryModalRecord] = useState<BreedingRecord | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Form states for Add Mating Record
  const [motherId, setMotherId] = useState('');
  const [ramId, setRamId] = useState('');
  const [matingDate, setMatingDate] = useState(new Date().toISOString().split('T')[0]);
  const [expectedDays, setExpectedDays] = useState(148);
  const [notes, setNotes] = useState('');

  // Form states for Delivery Recording
  const [actualLambingDate, setActualLambingDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [newbornCount, setNewbornCount] = useState(1);
  const [newbornsList, setNewbornsList] = useState<NewbornDetail[]>([
    {
      id: 'nb-1',
      sex: 'female',
      birthWeightKg: 3.5,
      color: 'بيضاء',
      condition: 'alive',
    },
  ]);
  const [autoRegisterInHerd, setAutoRegisterInHerd] = useState(true);

  const breedings = SheepDB.getBreedings();
  const animals = SheepDB.getAnimals().filter((a) => a.status !== 'sold' && a.status !== 'dead');
  const females = animals.filter((a) => a.sex === 'female');
  const males = animals.filter((a) => a.sex === 'male');

  const filtered = breedings.filter((b) => {
    if (filterStatus === 'all') return true;
    return b.status === filterStatus;
  });

  const handleOpenDeliveryModal = (rec: BreedingRecord) => {
    setDeliveryModalRecord(rec);
    setActualLambingDate(new Date().toISOString().split('T')[0]);
    setNewbornCount(1);
    setNewbornsList([
      {
        id: `nb-${Date.now()}-1`,
        sex: 'female',
        birthWeightKg: 3.5,
        color: 'بيضاء',
        condition: 'alive',
      },
    ]);
    setAutoRegisterInHerd(true);
  };

  const handleNewbornCountChange = (count: number) => {
    const validCount = Math.max(1, Math.min(5, count));
    setNewbornCount(validCount);

    const current = [...newbornsList];
    while (current.length < validCount) {
      current.push({
        id: `nb-${Date.now()}-${current.length + 1}`,
        sex: current.length % 2 === 0 ? 'female' : 'male',
        birthWeightKg: 3.5,
        color: 'بيضاء',
        condition: 'alive',
      });
    }
    setNewbornsList(current.slice(0, validCount));
  };

  const handleUpdateNewborn = (index: number, partial: Partial<NewbornDetail>) => {
    const updated = [...newbornsList];
    updated[index] = { ...updated[index], ...partial };
    setNewbornsList(updated);
  };

  const handleSaveMating = (e: React.FormEvent) => {
    e.preventDefault();
    if (!motherId || !ramId) {
      alert('يرجى اختيار النعجة الأم والكبش الملقح');
      return;
    }

    const expectedDate = calculateExpectedLambing(matingDate, expectedDays);

    SheepDB.addBreeding({
      motherId,
      ramId,
      matingDate,
      expectedLambingDate: expectedDate,
      status: 'pregnant',
      newbornCount: 0,
      newborns: [],
      notes,
    });

    setIsAddModalOpen(false);
    setMotherId('');
    setNotes('');
    setRefreshKey((k) => k + 1);
  };

  const handleSaveDelivery = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deliveryModalRecord) return;

    // If auto register in herd is enabled, create new animal records for live newborns
    const registeredNewborns = newbornsList.map((nb) => {
      if (autoRegisterInHerd && (nb.condition === 'alive' || nb.condition === 'weak')) {
        const newAnimal = SheepDB.addAnimal({
          sex: nb.sex,
          birthDate: actualLambingDate,
          source: 'farm_born',
          color: nb.color,
          motherId: deliveryModalRecord.motherId,
          fatherId: deliveryModalRecord.ramId,
          notes: `ولادة طبيعية في المزرعة (وزن الولادة: ${nb.birthWeightKg} كغ)`,
          status: 'healthy',
          photo: nb.photo,
        });
        return { ...nb, registeredAnimalId: newAnimal.id };
      }
      return nb;
    });

    SheepDB.updateBreeding({
      ...deliveryModalRecord,
      actualLambingDate,
      status: 'delivered',
      newbornCount,
      newborns: registeredNewborns,
    });

    setDeliveryModalRecord(null);
    setRefreshKey((k) => k + 1);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف سجل التلقيح هذا؟')) {
      SheepDB.deleteBreeding(id);
      setRefreshKey((k) => k + 1);
    }
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Header & Filter Controls */}
      <div className="space-y-2 sticky top-[60px] z-20 bg-stone-50 pt-1 pb-2">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            type="button"
            onClick={() => setFilterStatus('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterStatus === 'all'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            الكل ({breedings.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterStatus('pregnant')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterStatus === 'pregnant'
                ? 'bg-amber-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-amber-700 hover:bg-amber-50'
            }`}
          >
            حوامل قيد الانتظار ({breedings.filter((b) => b.status === 'pregnant').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterStatus('delivered')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterStatus === 'delivered'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-emerald-700 hover:bg-emerald-50'
            }`}
          >
            تمت الولادة ({breedings.filter((b) => b.status === 'delivered').length})
          </button>
        </div>
      </div>

      {/* List of Breeding Records */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-xs space-y-2">
          <Heart size={32} className="text-stone-300 mx-auto" />
          <p className="text-xs font-bold text-stone-700">لا توجد سجلات تلقيح أو ولادة</p>
          <p className="text-[11px] text-stone-400">سجل عمليات التلقيح لمتابعة مدة الحمل وتاريخ الولادة.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((rec) => {
            const countdown = getDaysUntilLambing(rec.expectedLambingDate);

            return (
              <div
                key={rec.id}
                className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-xs space-y-3 relative"
              >
                {/* Top Row: Mother & Ram Info */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-xl bg-pink-100 text-pink-700 flex items-center justify-center font-bold text-xs">
                      {rec.motherId}
                    </span>
                    <div>
                      <div className="font-bold text-stone-900 text-xs">
                        النعجة الأم: {rec.motherId} × الفحل: {rec.ramId}
                      </div>
                      <div className="text-[11px] text-stone-500">
                        تاريخ التلقيح: {formatDateArabic(rec.matingDate)}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <span
                      className={`px-2 py-0.5 rounded-lg text-[10px] font-bold ${
                        rec.status === 'pregnant'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : rec.status === 'delivered'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {rec.status === 'pregnant'
                        ? 'حامل'
                        : rec.status === 'delivered'
                        ? 'وضعت'
                        : 'إجهاض'}
                    </span>

                    <button
                      type="button"
                      onClick={() => handleDelete(rec.id)}
                      className="p-1 rounded-lg text-stone-400 hover:text-red-500 transition"
                      title="حذف السجل"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                {/* Pregnant Status Countdown Banner */}
                {rec.status === 'pregnant' && (
                  <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 flex items-center justify-between">
                    <div className="space-y-0.5">
                      <div className="text-[11px] text-amber-900 font-semibold flex items-center gap-1">
                        <Clock size={13} className="text-amber-700" />
                        <span>الولادة المتوقعة: {formatDateArabic(rec.expectedLambingDate)}</span>
                      </div>
                      <div className="text-[10px] text-amber-700">
                        (متوسط فترة حمل النعاج: 147 - 150 يوماً)
                      </div>
                    </div>

                    <div className="text-left">
                      <span
                        className={`text-xs font-bold px-2 py-1 rounded-lg ${
                          countdown.isOverdue
                            ? 'bg-red-100 text-red-800'
                            : 'bg-amber-200/60 text-amber-900'
                        }`}
                      >
                        {countdown.text}
                      </span>
                    </div>
                  </div>
                )}

                {/* Delivered Info and Newborns */}
                {rec.status === 'delivered' && (
                  <div className="p-3 rounded-xl bg-emerald-50/60 border border-emerald-200/80 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-emerald-900">
                        تاريخ الوضع الفعلي: {formatDateArabic(rec.actualLambingDate || '')}
                      </span>
                      <span className="font-bold text-emerald-800">
                        عدد المواليد: {rec.newbornCount}
                      </span>
                    </div>

                    {rec.newborns && rec.newborns.length > 0 && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                        {rec.newborns.map((nb, i) => (
                          <div
                            key={i}
                            className="p-2 rounded-lg bg-white border border-emerald-100 text-xs flex items-center justify-between"
                          >
                            <div className="flex items-center gap-1.5">
                              <span className="text-sm">🐑</span>
                              <div>
                                <span className="font-bold text-stone-900">
                                  {nb.sex === 'female' ? 'نعجة' : 'خروف'} ({nb.color})
                                </span>
                                {nb.registeredAnimalId && (
                                  <span className="text-[10px] font-bold text-emerald-700 mr-1 bg-emerald-50 px-1 rounded">
                                    رقم: {nb.registeredAnimalId}
                                  </span>
                                )}
                              </div>
                            </div>
                            <div className="text-left">
                              <span className="font-bold text-stone-700 tabular-nums">
                                {nb.birthWeightKg} كغ
                              </span>
                              <span
                                className={`text-[10px] font-medium mr-1.5 ${
                                  nb.condition === 'alive'
                                    ? 'text-emerald-700'
                                    : nb.condition === 'weak'
                                    ? 'text-amber-700'
                                    : 'text-red-700'
                                }`}
                              >
                                {nb.condition === 'alive'
                                  ? 'حي'
                                  : nb.condition === 'weak'
                                  ? 'ضعيف'
                                  : 'نافق'}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}

                {/* Action button if still pregnant */}
                {rec.status === 'pregnant' && (
                  <div className="pt-1">
                    <button
                      type="button"
                      onClick={() => handleOpenDeliveryModal(rec)}
                      className="w-full py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-xs transition cursor-pointer"
                    >
                      <Baby size={16} />
                      <span>تسجيل حدوث الولادة وتفاصيل المواليد</span>
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-emerald-950/20 transition cursor-pointer"
      >
        <Plus size={18} />
        <span>تسجيل تلقيح جديد</span>
      </button>

      {/* Modal 1: Add Mating / Pregnancy */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
              <h2 className="text-base font-bold">تسجيل عملية تلقيح جديدة</h2>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveMating} className="p-5 space-y-4 text-xs overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  النعجة الأم (إناث السجل N..) <span className="text-red-500">*</span>
                </label>
                <select
                  value={motherId}
                  onChange={(e) => setMotherId(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                  required
                >
                  <option value="">اختر النعجة...</option>
                  {females.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.id} ({f.color})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  الكبش الملقح (الفحل K..) <span className="text-red-500">*</span>
                </label>
                <select
                  value={ramId}
                  onChange={(e) => setRamId(e.target.value)}
                  className="w-full h-11 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                  required
                >
                  <option value="">اختر الكبش...</option>
                  {males.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.id} ({m.color} - {m.markings || 'فحل'})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ التلقيح</label>
                <input
                  type="date"
                  value={matingDate}
                  onChange={(e) => setMatingDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  required
                />
              </div>

              {/* Expected Lambing calculation preview */}
              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 space-y-1">
                <span className="text-amber-800 font-bold block">
                  تاريخ الولادة المتوقع تلقائياً:
                </span>
                <span className="text-sm font-black text-amber-950">
                  {formatDateArabic(calculateExpectedLambing(matingDate, expectedDays))}
                </span>
                <p className="text-[10px] text-amber-700">
                  تم الحساب على أساس 148 يوماً (بين 147 إلى 150 يوماً).
                </p>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="ملاحظات حول حالة النعجة أو التلقيح..."
                  className="w-full p-2.5 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>حفظ التلقيح وبدء المتابعة</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Record Actual Lambing & Newborns Details */}
      {deliveryModalRecord && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
              <div>
                <h2 className="text-base font-bold">
                  تسجيل ولادة النعجة {deliveryModalRecord.motherId}
                </h2>
                <p className="text-[11px] text-emerald-200">
                  تسجيل تاريخ الوضع الفعلي وبيانات المواليد (الوزن، الجنس، الحالة)
                </p>
              </div>
              <button
                type="button"
                onClick={() => setDeliveryModalRecord(null)}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveDelivery} className="p-5 space-y-4 text-xs overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    تاريخ الولادة الفعلي
                  </label>
                  <input
                    type="date"
                    value={actualLambingDate}
                    onChange={(e) => setActualLambingDate(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">عدد المواليد</label>
                  <div className="flex items-center gap-2">
                    {[1, 2, 3].map((num) => (
                      <button
                        key={num}
                        type="button"
                        onClick={() => handleNewbornCountChange(num)}
                        className={`flex-1 h-10 rounded-xl font-bold text-xs transition border cursor-pointer ${
                          newbornCount === num
                            ? 'bg-emerald-700 border-emerald-700 text-white shadow-xs'
                            : 'bg-stone-50 border-stone-200 text-stone-700'
                        }`}
                      >
                        {num === 1 ? 'مفرد (1)' : num === 2 ? 'توأم (2)' : 'ثلاثي (3)'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Newborns List Cards */}
              <div className="space-y-3">
                <h3 className="font-bold text-xs text-stone-800">بيانات كل مولود:</h3>
                {newbornsList.map((nb, idx) => (
                  <div
                    key={nb.id}
                    className="p-3.5 rounded-xl bg-stone-50 border border-stone-200/80 space-y-2.5"
                  >
                    <div className="flex items-center justify-between font-bold text-stone-800 text-xs">
                      <span>المولود #{idx + 1}</span>
                      <div className="flex gap-1">
                        <button
                          type="button"
                          onClick={() => handleUpdateNewborn(idx, { sex: 'female' })}
                          className={`px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer ${
                            nb.sex === 'female'
                              ? 'bg-pink-600 text-white'
                              : 'bg-stone-200 text-stone-700'
                          }`}
                        >
                          أنثى
                        </button>
                        <button
                          type="button"
                          onClick={() => handleUpdateNewborn(idx, { sex: 'male' })}
                          className={`px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer ${
                            nb.sex === 'male'
                              ? 'bg-blue-600 text-white'
                              : 'bg-stone-200 text-stone-700'
                          }`}
                        >
                          ذكر
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[10px] text-stone-500 mb-0.5">
                          وزن الولادة (كغ)
                        </label>
                        <input
                          type="number"
                          step="0.1"
                          min="0.5"
                          max="10"
                          value={nb.birthWeightKg}
                          onChange={(e) =>
                            handleUpdateNewborn(idx, {
                              birthWeightKg: parseFloat(e.target.value) || 0,
                            })
                          }
                          className="w-full h-9 px-2 rounded-lg border border-stone-300 bg-white text-xs font-bold tabular-nums"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-stone-500 mb-0.5">اللون</label>
                        <input
                          type="text"
                          value={nb.color}
                          onChange={(e) => handleUpdateNewborn(idx, { color: e.target.value })}
                          className="w-full h-9 px-2 rounded-lg border border-stone-300 bg-white text-xs"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] text-stone-500 mb-0.5">الحالة</label>
                        <select
                          value={nb.condition}
                          onChange={(e) =>
                            handleUpdateNewborn(idx, {
                              condition: e.target.value as NewbornCondition,
                            })
                          }
                          className="w-full h-9 px-1 rounded-lg border border-stone-300 bg-white text-[11px] font-bold"
                        >
                          <option value="alive">حي وسليم</option>
                          <option value="weak">ضعيف</option>
                          <option value="dead">نافق</option>
                        </select>
                      </div>
                    </div>

                    {/* Photo for newborn */}
                    <PhotoPicker
                      label="صورة المولود"
                      value={nb.photo}
                      onChange={(p) => handleUpdateNewborn(idx, { photo: p })}
                    />
                  </div>
                ))}
              </div>

              {/* Auto Register Checkbox */}
              <label className="flex items-center gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoRegisterInHerd}
                  onChange={(e) => setAutoRegisterInHerd(e.target.checked)}
                  className="w-4 h-4 text-emerald-600 rounded"
                />
                <span className="text-xs font-bold text-emerald-950">
                  إضافة المواليد الأحياء تلقائياً إلى سجل الأغنام بأرقام جديدة (N.. / K..)
                </span>
              </label>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>حفظ وتأكيد تسجيل الولادة</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
