import React, { useState } from 'react';
import {
  Bell,
  Plus,
  CheckCircle2,
  Circle,
  Calendar,
  Trash2,
  Edit2,
  Clock,
  X,
  Save,
  AlertCircle,
} from 'lucide-react';
import { ReminderCategory, ReminderItem, ReminderPriority } from '../types';
import { SheepDB } from '../store/database';
import { formatDateArabic } from '../utils/formatters';

const REMINDER_CATEGORIES: Record<
  ReminderCategory,
  { label: string; icon: string; color: string }
> = {
  lambing: { label: 'ولادة متوقعة', icon: '🐑', color: 'bg-amber-100 text-amber-900 border-amber-200' },
  vaccination: { label: 'تطعيم ولقاح', icon: '💉', color: 'bg-blue-100 text-blue-900 border-blue-200' },
  treatment: { label: 'علاج ودواء', icon: '🩺', color: 'bg-red-100 text-red-900 border-red-200' },
  mating: { label: 'تلقيح ونزو', icon: '❤️', color: 'bg-pink-100 text-pink-900 border-pink-200' },
  feed: { label: 'تغذية ومخزون', icon: '🌾', color: 'bg-emerald-100 text-emerald-900 border-emerald-200' },
  custom: { label: 'تذكير مخصص', icon: '📌', color: 'bg-purple-100 text-purple-900 border-purple-200' },
};

export const RemindersView: React.FC = () => {
  const [filter, setFilter] = useState<'pending' | 'completed' | 'all'>('pending');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReminder, setEditingReminder] = useState<ReminderItem | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Form
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<ReminderCategory>('lambing');
  const [targetDate, setTargetDate] = useState(new Date().toISOString().split('T')[0]);
  const [animalId, setAnimalId] = useState('');
  const [priority, setPriority] = useState<ReminderPriority>('high');
  const [notes, setNotes] = useState('');

  const reminders = SheepDB.getReminders();
  const animals = SheepDB.getAnimals().filter((a) => a.status !== 'sold' && a.status !== 'dead');

  const filtered = reminders.filter((r) => {
    if (filter === 'pending') return !r.isCompleted;
    if (filter === 'completed') return r.isCompleted;
    return true;
  });

  const handleToggle = (id: string) => {
    SheepDB.toggleReminder(id);
    setRefreshKey((k) => k + 1);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا التذكير؟')) {
      SheepDB.deleteReminder(id);
      setRefreshKey((k) => k + 1);
    }
  };

  const handleOpenAdd = () => {
    setEditingReminder(null);
    setTitle('');
    setCategory('lambing');
    setTargetDate(new Date().toISOString().split('T')[0]);
    setAnimalId('');
    setPriority('high');
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (rem: ReminderItem) => {
    setEditingReminder(rem);
    setTitle(rem.title);
    setCategory(rem.category);
    setTargetDate(rem.targetDate);
    setAnimalId(rem.animalId || '');
    setPriority(rem.priority);
    setNotes(rem.notes || '');
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title) {
      alert('يرجى كتابة عنوان التذكير');
      return;
    }

    if (editingReminder) {
      SheepDB.updateReminder({
        ...editingReminder,
        title,
        category,
        targetDate,
        animalId: animalId || undefined,
        priority,
        notes,
      });
    } else {
      SheepDB.addReminder({
        title,
        category,
        targetDate,
        animalId: animalId || undefined,
        priority,
        notes,
      });
    }

    setIsModalOpen(false);
    setEditingReminder(null);
    setRefreshKey((k) => k + 1);
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Tabs */}
      <div className="flex gap-1.5 sticky top-[60px] z-20 bg-stone-50 pt-1 pb-2">
        <button
          type="button"
          onClick={() => setFilter('pending')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            filter === 'pending'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'bg-white border border-stone-200 text-stone-600'
          }`}
        >
          المواعيد النشطة ({reminders.filter((r) => !r.isCompleted).length})
        </button>
        <button
          type="button"
          onClick={() => setFilter('completed')}
          className={`flex-1 py-2 text-xs font-bold rounded-xl transition ${
            filter === 'completed'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'bg-white border border-stone-200 text-stone-600'
          }`}
        >
          المكتملة ({reminders.filter((r) => r.isCompleted).length})
        </button>
        <button
          type="button"
          onClick={() => setFilter('all')}
          className={`px-3 py-2 text-xs font-bold rounded-xl transition ${
            filter === 'all'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'bg-white border border-stone-200 text-stone-600'
          }`}
        >
          الكل ({reminders.length})
        </button>
      </div>

      {/* Reminders List */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-xs space-y-2">
          <Bell size={32} className="text-stone-300 mx-auto" />
          <p className="text-xs font-bold text-stone-700">لا توجد تنبيهات في هذا القسم</p>
          <p className="text-[11px] text-stone-400">
            أضف تذكيرات لمواعيد الولادات واللقاحات والعلاجات لضمان متابعة القطيع بدقة.
          </p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((rem) => {
            const catInfo = REMINDER_CATEGORIES[rem.category] || REMINDER_CATEGORIES.custom;

            return (
              <div
                key={rem.id}
                className={`bg-white rounded-2xl p-3.5 border transition flex items-start justify-between gap-3 shadow-xs ${
                  rem.isCompleted
                    ? 'border-stone-200 opacity-60 bg-stone-50/50'
                    : rem.priority === 'high'
                    ? 'border-amber-300 bg-amber-50/20'
                    : 'border-stone-200/80'
                }`}
              >
                {/* Toggle Checkbox Button */}
                <button
                  type="button"
                  onClick={() => handleToggle(rem.id)}
                  className="mt-0.5 text-emerald-700 hover:text-emerald-800 transition cursor-pointer"
                  title={rem.isCompleted ? 'إعادة إلى قيد الانتظار' : 'تحديد كمكتمل'}
                >
                  {rem.isCompleted ? (
                    <CheckCircle2 size={20} className="text-emerald-600" />
                  ) : (
                    <Circle size={20} className="text-stone-300 hover:text-stone-500" />
                  )}
                </button>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${catInfo.color}`}
                    >
                      {catInfo.icon} {catInfo.label}
                    </span>

                    {rem.animalId && (
                      <span className="text-[10px] font-bold bg-stone-100 text-stone-800 px-1.5 py-0.5 rounded">
                        رقم: {rem.animalId}
                      </span>
                    )}

                    {rem.priority === 'high' && !rem.isCompleted && (
                      <span className="text-[10px] font-bold text-red-700 bg-red-100 px-1.5 py-0.5 rounded">
                        هام وعاجل
                      </span>
                    )}
                  </div>

                  <h3
                    className={`font-bold text-xs mt-1 text-stone-900 ${
                      rem.isCompleted ? 'line-through text-stone-400' : ''
                    }`}
                  >
                    {rem.title}
                  </h3>

                  <div className="text-[11px] text-stone-500 flex items-center gap-1 mt-0.5">
                    <Calendar size={12} className="text-stone-400" />
                    <span>الموعد: {formatDateArabic(rem.targetDate)}</span>
                  </div>

                  {rem.notes && (
                    <p className="text-[10px] text-stone-500 mt-1 whitespace-pre-wrap">{rem.notes}</p>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="flex flex-col gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleOpenEdit(rem)}
                    className="p-1 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded"
                    title="تعديل الموعد"
                  >
                    <Edit2 size={13} />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(rem.id)}
                    className="p-1 text-stone-400 hover:text-red-600 hover:bg-red-50 rounded"
                    title="حذف"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={handleOpenAdd}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-emerald-950/20 transition cursor-pointer"
      >
        <Plus size={18} />
        <span>إضافة تذكير جديد</span>
      </button>

      {/* Modal: Add/Edit Reminder */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-[#1b4332] text-white">
              <h2 className="text-base font-bold">
                {editingReminder ? 'تعديل التذكير' : 'إضافة تذكير أو موعد جديد'}
              </h2>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-3.5 text-xs overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">نوع التذكير</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ReminderCategory)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                >
                  {Object.entries(REMINDER_CATEGORIES).map(([key, info]) => (
                    <option key={key} value={key}>
                      {info.icon} {info.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  عنوان التذكير <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: موعد ولادة النعجة N 1، جرعة التطعيم الثانية..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ الموعد</label>
                  <input
                    type="date"
                    value={targetDate}
                    onChange={(e) => setTargetDate(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">الرأس المعني</label>
                  <select
                    value={animalId}
                    onChange={(e) => setAnimalId(e.target.value)}
                    className="w-full h-10 px-2 rounded-xl border border-stone-300 text-xs bg-white"
                  >
                    <option value="">كامل القطيع / غير محدد</option>
                    {animals.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.id} ({a.sex === 'female' ? 'نعجة' : 'كبش'})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">مستوى الأهمية</label>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'high', label: 'عالي / حرج' },
                    { id: 'normal', label: 'عادي' },
                    { id: 'low', label: 'منخفض' },
                  ].map((p) => (
                    <button
                      key={p.id}
                      type="button"
                      onClick={() => setPriority(p.id as ReminderPriority)}
                      className={`py-2 rounded-xl text-center font-bold text-xs border cursor-pointer ${
                        priority === p.id
                          ? 'bg-emerald-700 border-emerald-700 text-white'
                          : 'bg-stone-50 border-stone-200 text-stone-700'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={2}
                  placeholder="تعليمات أو تجهيزات مطلوبة..."
                  className="w-full p-2.5 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>{editingReminder ? 'حفظ التعديلات' : 'تفعيل التذكير'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
