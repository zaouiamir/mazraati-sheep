import React, { useRef, useState } from 'react';
import {
  Download,
  Upload,
  RefreshCw,
  Settings,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  HardDrive,
  FileJson,
  Smartphone,
} from 'lucide-react';
import { SheepDB } from '../store/database';
import { formatDzd, formatCentimes, formatDualCurrency } from '../utils/formatters';

export const BackupSettingsView: React.FC = () => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [statusMessage, setStatusMessage] = useState<{ text: string; isError: boolean } | null>(
    null
  );
  const [settings, setSettings] = useState(SheepDB.getSettings());

  const handleExportBackup = () => {
    try {
      const json = SheepDB.exportBackupJson();
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const dateStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `mazraati_sheep_backup_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setStatusMessage({
        text: 'تم تصدير ملف النسخة الاحتياطية بنجاح إلى هاتفك.',
        isError: false,
      });
    } catch (e) {
      setStatusMessage({
        text: 'حدث خطأ أثناء تصدير النسخة الاحتياطية.',
        isError: true,
      });
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!confirm('تنبيه: استعادة نسخة احتياطية ستقوم باستبدال كافة السجلات الحالية في التطبيق. هل أنت متأكد من المتابعة؟')) {
      e.target.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = SheepDB.importBackupJson(content);
      if (res.success) {
        setStatusMessage({ text: res.message, isError: false });
        setSettings(SheepDB.getSettings());
        setTimeout(() => window.location.reload(), 1500);
      } else {
        setStatusMessage({ text: res.message, isError: true });
      }
    };
    reader.readAsText(file);
  };

  const handleResetToSeed = () => {
    if (
      confirm(
        'هل أنت متأكد من إعادة ضبط البيانات إلى الحالة الأصلية (رأس مال 120 مليون سنتيم و14 مصروفاً و7 رؤوس غنم)؟'
      )
    ) {
      SheepDB.resetToInitialData();
      setStatusMessage({
        text: 'تمت استعادة البيانات الابتدائية ورأس المال بنجاح.',
        isError: false,
      });
      setTimeout(() => window.location.reload(), 1000);
    }
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Page Title */}
      <div className="px-1">
        <h2 className="text-base font-bold text-stone-900 flex items-center gap-2">
          <Settings size={18} className="text-emerald-700" />
          <span>النسخ الاحتياطي وإعدادات التطبيق</span>
        </h2>
        <p className="text-xs text-stone-500">حفظ دائم على جهازك دون اتصال بالإنترنت</p>
      </div>

      {/* Status banner */}
      {statusMessage && (
        <div
          className={`p-3 rounded-2xl text-xs font-semibold flex items-center gap-2 ${
            statusMessage.isError
              ? 'bg-red-50 text-red-800 border border-red-200'
              : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
          }`}
        >
          {statusMessage.isError ? (
            <AlertTriangle size={16} className="text-red-600 shrink-0" />
          ) : (
            <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
          )}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Backup and Restore Card */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs space-y-4">
        <div className="flex items-center gap-2">
          <HardDrive size={18} className="text-emerald-700" />
          <h3 className="font-bold text-xs text-stone-800">النسخ الاحتياطي الكامل لقاعدة البيانات</h3>
        </div>
        <p className="text-xs text-stone-500 leading-relaxed">
          يمكنك في أي وقت تنزيل نسخة احتياطية شاملة تحتوي على جميع سجلات الأغنام، التلقيح، المواليد،
          المصاريف، المداخيل، والصور الفوتوغرافية، واستعادتها في أي وقت بدون إنترنت.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          {/* Export Button */}
          <button
            type="button"
            onClick={handleExportBackup}
            className="flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition active:scale-98 cursor-pointer"
          >
            <Download size={16} />
            <span>تصدير نسخة احتياطية (ملف JSON)</span>
          </button>

          {/* Import Button */}
          <div>
            <input
              type="file"
              accept=".json,application/json"
              ref={fileInputRef}
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 font-bold text-xs border border-stone-300 transition active:scale-98 cursor-pointer"
            >
              <Upload size={16} />
              <span>استعادة نسخة احتياطية من الهاتف</span>
            </button>
          </div>
        </div>
      </div>

      {/* Capital & Currency Info */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200/80 shadow-xs space-y-3">
        <h3 className="font-bold text-xs text-stone-800">بيانات رأس المال والعملة</h3>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-stone-600">رأس المال الابتدائي:</span>
            <span className="font-extrabold text-stone-900 tabular-nums">
              1,200,000 د.ج (120,000,000 سنتيم)
            </span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-stone-600">نظام الحساب والعملة:</span>
            <span className="font-bold text-emerald-800">الدينار الجزائري (DZD) والسنتيم</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-stone-600">تسلسل ترقيم الإناث الحالي:</span>
            <span className="font-bold text-pink-700">N {settings.lastFemaleSequence}</span>
          </div>

          <div className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 border border-stone-200">
            <span className="text-stone-600">تسلسل ترقيم الذكور الحالي:</span>
            <span className="font-bold text-blue-700">K {settings.lastMaleSequence}</span>
          </div>
        </div>
      </div>

      {/* Danger Zone: Reset to Initial Data */}
      <div className="bg-white rounded-2xl p-5 border border-red-200 shadow-xs space-y-3">
        <div className="flex items-center gap-2 text-red-700">
          <AlertTriangle size={18} />
          <h3 className="font-bold text-xs">منطقة إعادة الضبط</h3>
        </div>
        <p className="text-xs text-stone-500">
          إعادة تعيين قاعدة البيانات إلى الحالة الابتدائية الأصلية مع الاحتفاظ بالمصاريف الـ14 التاريخية
          ورأس المال (120 مليون سنتيم).
        </p>

        <button
          type="button"
          onClick={handleResetToSeed}
          className="py-2.5 px-4 rounded-xl bg-red-50 hover:bg-red-100 text-red-800 font-bold text-xs border border-red-300 transition active:scale-98 cursor-pointer flex items-center justify-center gap-2"
        >
          <RefreshCw size={14} />
          <span>استرجاع الحالة الابتدائية المعتمدة للمزرعة</span>
        </button>
      </div>
    </div>
  );
};
