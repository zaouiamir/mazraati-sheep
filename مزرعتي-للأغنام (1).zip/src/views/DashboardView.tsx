import React from 'react';
import {
  Layers,
  Heart,
  CreditCard,
  TrendingUp,
  Wallet,
  PlusCircle,
  Bell,
  Calendar,
  AlertCircle,
  ChevronLeft,
  Wheat,
  Activity,
  ArrowUpRight,
  ArrowDownLeft,
} from 'lucide-react';
import { NavigationSection } from '../types';
import { SheepDB } from '../store/database';
import { formatDzd, formatCentimes, formatDualCurrency, formatDateArabic } from '../utils/formatters';

interface DashboardViewProps {
  onNavigate: (section: NavigationSection) => void;
  onOpenAddAnimal: () => void;
  onOpenAddExpense: () => void;
  onOpenAddBreeding: () => void;
  onOpenAddHealth: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenAddAnimal,
  onOpenAddExpense,
  onOpenAddBreeding,
  onOpenAddHealth,
}) => {
  const flock = SheepDB.getFlockSummary();
  const finance = SheepDB.getFinancialSummary();
  const breedings = SheepDB.getBreedings();
  const reminders = SheepDB.getReminders().filter((r) => !r.isCompleted);

  const pregnantEwes = breedings.filter((b) => b.status === 'pregnant');

  return (
    <div className="space-y-4 pb-20">
      {/* Capital Summary Hero Card (بطاقة رأس المال والمؤشرات المالية) */}
      <div className="bg-gradient-to-br from-[#1b4332] via-[#2d6a4f] to-[#1b4332] rounded-2xl p-5 text-white shadow-md relative overflow-hidden">
        {/* Subtle decorative background curves */}
        <div className="absolute -left-12 -top-12 w-40 h-40 bg-white/5 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -right-8 -bottom-8 w-32 h-32 bg-emerald-400/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10">
          <div className="flex items-center justify-between text-emerald-200 text-xs font-semibold mb-1">
            <span className="flex items-center gap-1.5">
              <Wallet size={16} className="text-emerald-300" />
              <span>رأس المال المتبقي في الصندوق</span>
            </span>
            <span className="bg-emerald-900/60 px-2 py-0.5 rounded-full text-[11px] border border-emerald-400/20">
              محدث محلياً
            </span>
          </div>

          {/* Big primary number in DZD */}
          <div className="text-3xl font-extrabold tracking-tight tabular-nums text-white mt-1">
            {formatDzd(finance.remainingCapitalCentimes)}
          </div>
          {/* Centimes equivalent */}
          <div className="text-xs text-emerald-200/90 font-medium tabular-nums mt-0.5">
            يعادل: {formatCentimes(finance.remainingCapitalCentimes)}
          </div>

          {/* Divider */}
          <div className="h-px bg-white/15 my-3" />

          {/* Starting Capital & Totals Strip */}
          <div className="grid grid-cols-3 gap-2 text-center text-xs">
            <div className="bg-black/20 rounded-xl p-2 border border-white/5">
              <div className="text-[11px] text-emerald-200/80">رأس المال الأولي</div>
              <div className="font-bold text-white tabular-nums mt-0.5 text-xs sm:text-sm">
                {formatDzd(finance.startingCapitalCentimes)}
              </div>
              <div className="text-[9px] text-emerald-300/80 tabular-nums">120 مليون سنتيم</div>
            </div>

            <div className="bg-black/20 rounded-xl p-2 border border-white/5">
              <div className="text-[11px] text-red-200/80 flex items-center justify-center gap-0.5">
                <ArrowDownLeft size={12} className="text-red-400" />
                <span>إجمالي المصاريف</span>
              </div>
              <div className="font-bold text-red-200 tabular-nums mt-0.5 text-xs sm:text-sm">
                {formatDzd(finance.totalExpensesCentimes)}
              </div>
              <div className="text-[9px] text-red-300/80 tabular-nums">
                {formatCentimes(finance.totalExpensesCentimes)}
              </div>
            </div>

            <div className="bg-black/20 rounded-xl p-2 border border-white/5">
              <div className="text-[11px] text-emerald-200/80 flex items-center justify-center gap-0.5">
                <ArrowUpRight size={12} className="text-emerald-400" />
                <span>إجمالي المداخيل</span>
              </div>
              <div className="font-bold text-emerald-300 tabular-nums mt-0.5 text-xs sm:text-sm">
                {formatDzd(finance.totalIncomeCentimes)}
              </div>
              <div className="text-[9px] text-emerald-300/80 tabular-nums">
                {formatCentimes(finance.totalIncomeCentimes)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Flock Overview Section (إحصائيات القطيع الحالية) */}
      <div className="space-y-2">
        <div className="flex items-center justify-between px-1">
          <h2 className="text-sm font-bold text-stone-800 flex items-center gap-1.5">
            <Layers size={16} className="text-emerald-700" />
            <span>تعداد قطيع الأغنام الحالي</span>
          </h2>
          <button
            type="button"
            onClick={() => onNavigate('animals')}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-0.5 cursor-pointer"
          >
            <span>عرض السجل</span>
            <ChevronLeft size={14} />
          </button>
        </div>

        {/* 4 Cards Grid for Flock Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          {/* Card 1: Total Present */}
          <div
            onClick={() => onNavigate('animals')}
            className="bg-white rounded-2xl p-3.5 border border-stone-200/80 shadow-xs hover:border-emerald-500/50 transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs text-stone-500 font-medium">
              <span>إجمالي الحاضر</span>
              <span className="w-6 h-6 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center text-xs">
                🐑
              </span>
            </div>
            <div className="text-2xl font-black text-stone-900 tabular-nums mt-1.5">
              {flock.totalPresent} <span className="text-xs font-normal text-stone-500">رأس</span>
            </div>
            <div className="text-[11px] text-emerald-700 font-medium mt-0.5">
              في المزرعة حالياً
            </div>
          </div>

          {/* Card 2: Females */}
          <div
            onClick={() => onNavigate('animals')}
            className="bg-white rounded-2xl p-3.5 border border-stone-200/80 shadow-xs hover:border-emerald-500/50 transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs text-stone-500 font-medium">
              <span>النعاج (إناث)</span>
              <span className="text-xs font-bold bg-pink-100 text-pink-700 px-1.5 py-0.5 rounded-md">
                N
              </span>
            </div>
            <div className="text-2xl font-black text-pink-700 tabular-nums mt-1.5">
              {flock.femalesCount} <span className="text-xs font-normal text-stone-500">نعجة</span>
            </div>
            <div className="text-[11px] text-stone-500 font-medium mt-0.5">ترقيم تسلسلي N..</div>
          </div>

          {/* Card 3: Males */}
          <div
            onClick={() => onNavigate('animals')}
            className="bg-white rounded-2xl p-3.5 border border-stone-200/80 shadow-xs hover:border-emerald-500/50 transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs text-stone-500 font-medium">
              <span>الكباش (ذكور)</span>
              <span className="text-xs font-bold bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-md">
                K
              </span>
            </div>
            <div className="text-2xl font-black text-blue-700 tabular-nums mt-1.5">
              {flock.malesCount} <span className="text-xs font-normal text-stone-500">كبش</span>
            </div>
            <div className="text-[11px] text-stone-500 font-medium mt-0.5">ترقيم تسلسلي K..</div>
          </div>

          {/* Card 4: Pregnant & Expected Births */}
          <div
            onClick={() => onNavigate('reproduction')}
            className="bg-white rounded-2xl p-3.5 border border-amber-200/80 shadow-xs bg-amber-50/20 hover:border-amber-500/50 transition cursor-pointer"
          >
            <div className="flex items-center justify-between text-xs text-stone-500 font-medium">
              <span>الحوامل والولادات</span>
              <Heart size={14} className="text-amber-600 fill-amber-500/30" />
            </div>
            <div className="text-2xl font-black text-amber-700 tabular-nums mt-1.5">
              {flock.pregnantEwesCount}{' '}
              <span className="text-xs font-normal text-stone-500">حامل</span>
            </div>
            <div className="text-[11px] text-amber-700 font-medium mt-0.5">
              {flock.expectedBirthsCount} ولادة متوقعة
            </div>
          </div>
        </div>
      </div>

      {/* Quick Action Buttons (أزرار الوصول السريع) */}
      <div className="space-y-2">
        <h2 className="text-xs font-bold text-stone-600 px-1">إجراءات سريعة رئيسية</h2>
        <div className="grid grid-cols-4 gap-2">
          {/* 1. Add Animal */}
          <button
            type="button"
            onClick={onOpenAddAnimal}
            className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white border border-stone-200/80 hover:bg-emerald-50 hover:border-emerald-300 transition text-stone-700 active:scale-95 cursor-pointer shadow-xs"
          >
            <div className="w-9 h-9 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-1">
              <PlusCircle size={18} />
            </div>
            <span className="text-[11px] font-bold text-stone-800 text-center leading-tight">إضافة رأس</span>
          </button>

          {/* 2. Add Expense */}
          <button
            type="button"
            onClick={onOpenAddExpense}
            className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white border border-stone-200/80 hover:bg-red-50 hover:border-red-300 transition text-stone-700 active:scale-95 cursor-pointer shadow-xs"
          >
            <div className="w-9 h-9 rounded-xl bg-red-100 text-red-700 flex items-center justify-center mb-1">
              <CreditCard size={18} />
            </div>
            <span className="text-[11px] font-bold text-stone-800 text-center leading-tight">تسجيل مصاريف</span>
          </button>

          {/* 3. Add Birth / Breeding */}
          <button
            type="button"
            onClick={onOpenAddBreeding}
            className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white border border-stone-200/80 hover:bg-pink-50 hover:border-pink-300 transition text-stone-700 active:scale-95 cursor-pointer shadow-xs"
          >
            <div className="w-9 h-9 rounded-xl bg-pink-100 text-pink-700 flex items-center justify-center mb-1">
              <Heart size={18} />
            </div>
            <span className="text-[11px] font-bold text-stone-800 text-center leading-tight">تسجيل ولادة</span>
          </button>

          {/* 4. Add Health Record */}
          <button
            type="button"
            onClick={onOpenAddHealth}
            className="flex flex-col items-center justify-center p-2.5 rounded-2xl bg-white border border-stone-200/80 hover:bg-blue-50 hover:border-blue-300 transition text-stone-700 active:scale-95 cursor-pointer shadow-xs"
          >
            <div className="w-9 h-9 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-1">
              <Activity size={18} />
            </div>
            <span className="text-[11px] font-bold text-stone-800 text-center leading-tight">سجل صحي</span>
          </button>
        </div>
      </div>

      {/* Active Pregnant Ewes & Expected Births (متابعة الحمل والولادات المتوقعة) */}
      {pregnantEwes.length > 0 && (
        <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
              <Calendar size={15} className="text-amber-600" />
              <span>مواعيد الولادات القادمة (فترة الحمل ~148 يوم)</span>
            </h3>
            <button
              type="button"
              onClick={() => onNavigate('reproduction')}
              className="text-[11px] font-semibold text-emerald-700 hover:underline"
            >
              عرض الكل
            </button>
          </div>

          <div className="space-y-2">
            {pregnantEwes.slice(0, 3).map((br) => (
              <div
                key={br.id}
                onClick={() => onNavigate('reproduction')}
                className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 border border-stone-200/60 hover:bg-amber-50/40 transition cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-pink-100 text-pink-800 flex items-center justify-center font-bold text-xs">
                    {br.motherId}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-stone-800">
                      النعجة {br.motherId} (مع الفحل {br.ramId})
                    </div>
                    <div className="text-[11px] text-stone-500">
                      تاريخ التلقيح: {formatDateArabic(br.matingDate)}
                    </div>
                  </div>
                </div>

                <div className="text-left">
                  <div className="text-xs font-bold text-amber-800">
                    {formatDateArabic(br.expectedLambingDate)}
                  </div>
                  <div className="text-[10px] text-amber-600 font-medium">ولادة متوقعة</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Reminders / Upcoming Alerts Strip */}
      {reminders.length > 0 && (
        <div className="bg-emerald-50/60 rounded-2xl p-4 border border-emerald-200/80 shadow-xs space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell size={16} className="text-emerald-800" />
              <h3 className="text-xs font-bold text-emerald-950">
                التنبيهات والمواعيد القادمة ({reminders.length})
              </h3>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('reminders')}
              className="text-[11px] font-semibold text-emerald-800 hover:underline"
            >
              إدارة التنبيهات
            </button>
          </div>

          <div className="space-y-1.5">
            {reminders.slice(0, 2).map((rem) => (
              <div
                key={rem.id}
                onClick={() => onNavigate('reminders')}
                className="flex items-center justify-between p-2 rounded-xl bg-white border border-emerald-100 text-xs text-stone-800 cursor-pointer hover:bg-emerald-50/30 transition"
              >
                <div className="flex items-center gap-2 truncate">
                  <span
                    className={`w-2 h-2 rounded-full shrink-0 ${
                      rem.priority === 'high' ? 'bg-red-500' : 'bg-emerald-600'
                    }`}
                  />
                  <span className="font-semibold truncate">{rem.title}</span>
                </div>
                <span className="text-[11px] text-stone-500 shrink-0 font-medium mr-2">
                  {formatDateArabic(rem.targetDate)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
