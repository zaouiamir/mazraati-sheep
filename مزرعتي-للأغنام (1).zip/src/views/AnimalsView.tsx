import React, { useState } from 'react';
import { Search, Plus, Filter, Heart, Eye } from 'lucide-react';
import { Animal, AnimalSex, AnimalStatus } from '../types';
import { SheepDB } from '../store/database';
import { calculateAgeArabic, formatDateArabic } from '../utils/formatters';
import { AnimalDetailModal } from './AnimalDetailModal';
import { AnimalFormModal } from './AnimalFormModal';

interface AnimalsViewProps {
  onOpenAddModal: () => void;
}

type FilterTab = 'all' | 'present' | 'healthy' | 'pregnant' | 'sick' | 'females' | 'males' | 'sold' | 'dead';

export const AnimalsView: React.FC<AnimalsViewProps> = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterTab, setFilterTab] = useState<FilterTab>('all');
  const [selectedAnimal, setSelectedAnimal] = useState<Animal | null>(null);
  const [editingAnimal, setEditingAnimal] = useState<Animal | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [refreshKey, setRefreshKey] = useState(0);

  const animals = SheepDB.getAnimals();
  const breedings = SheepDB.getBreedings();
  const pregnantMotherIds = new Set(
    breedings.filter((b) => b.status === 'pregnant').map((b) => b.motherId)
  );

  const filteredAnimals = animals.filter((animal) => {
    // Search filter
    const matchesSearch =
      animal.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      animal.color.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (animal.markings && animal.markings.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (animal.notes && animal.notes.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (animal.motherId && animal.motherId.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    // Tab filter
    if (filterTab === 'present') return animal.status !== 'sold' && animal.status !== 'dead';
    if (filterTab === 'healthy') return animal.status === 'healthy';
    if (filterTab === 'pregnant') return animal.status === 'pregnant' || pregnantMotherIds.has(animal.id);
    if (filterTab === 'sick') return animal.status === 'sick';
    if (filterTab === 'females') return animal.sex === 'female';
    if (filterTab === 'males') return animal.sex === 'male';
    if (filterTab === 'sold') return animal.status === 'sold';
    if (filterTab === 'dead') return animal.status === 'dead';

    return true;
  });

  const handleRefresh = () => {
    setRefreshKey((k) => k + 1);
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Search Bar & Quick Filters */}
      <div className="space-y-2 sticky top-[60px] z-20 bg-stone-50 pt-1 pb-2">
        <div className="relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالرقم (N 1, K 1)، اللون، الأم، الملاحظات..."
            className="w-full h-11 pl-4 pr-10 rounded-2xl border border-stone-300 bg-white text-xs font-medium focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 shadow-xs"
          />
          <Search size={18} className="absolute right-3.5 top-3 text-stone-400" />
        </div>

        {/* Filter Pills / Tabs */}
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            type="button"
            onClick={() => setFilterTab('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'all'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            الكل ({animals.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('present')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'present'
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            في المزرعة ({animals.filter((a) => a.status !== 'sold' && a.status !== 'dead').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('healthy')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'healthy'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-emerald-800 hover:bg-emerald-50'
            }`}
          >
            سليمة ({animals.filter((a) => a.status === 'healthy').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('pregnant')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'pregnant'
                ? 'bg-amber-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-amber-800 hover:bg-amber-50'
            }`}
          >
            حوامل ({animals.filter((a) => a.status === 'pregnant' || pregnantMotherIds.has(a.id)).length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('sick')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'sick'
                ? 'bg-orange-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-orange-800 hover:bg-orange-50'
            }`}
          >
            مريضة ({animals.filter((a) => a.status === 'sick').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('females')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'females'
                ? 'bg-pink-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-pink-700 hover:bg-pink-50'
            }`}
          >
            النعاج N ({animals.filter((a) => a.sex === 'female').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('males')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'males'
                ? 'bg-blue-700 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-blue-700 hover:bg-blue-50'
            }`}
          >
            الكباش K ({animals.filter((a) => a.sex === 'male').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('sold')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'sold'
                ? 'bg-stone-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            المباعة ({animals.filter((a) => a.status === 'sold').length})
          </button>
          <button
            type="button"
            onClick={() => setFilterTab('dead')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterTab === 'dead'
                ? 'bg-red-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-red-600 hover:bg-red-50'
            }`}
          >
            النافقة ({animals.filter((a) => a.status === 'dead').length})
          </button>
        </div>
      </div>

      {/* List of Animals */}
      {filteredAnimals.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-xs space-y-2">
          <div className="w-12 h-12 rounded-full bg-stone-100 text-stone-400 mx-auto flex items-center justify-center text-xl">
            🐑
          </div>
          <p className="text-xs font-bold text-stone-700">لا توجد رؤوس غنم مطابقة للبحث أو التصفية</p>
          <p className="text-[11px] text-stone-400">يمكنك إضافة رأس جديد عبر زر الإضافة أسفله.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {filteredAnimals.map((animal) => {
            const isPregnant = pregnantMotherIds.has(animal.id);
            const age = calculateAgeArabic(animal.birthDate);

            return (
              <div
                key={animal.id}
                onClick={() => setSelectedAnimal(animal)}
                className="bg-white rounded-2xl p-3 border border-stone-200/80 shadow-xs hover:border-emerald-500/60 hover:shadow-sm transition cursor-pointer flex gap-3 relative"
              >
                {/* Photo or placeholder */}
                {animal.photo ? (
                  <img
                    src={animal.photo}
                    alt={animal.id}
                    className="w-20 h-20 rounded-xl object-cover border border-stone-200 shrink-0"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div
                    className={`w-20 h-20 rounded-xl flex flex-col items-center justify-center shrink-0 border ${
                      animal.sex === 'female'
                        ? 'bg-pink-50 border-pink-200 text-pink-700'
                        : 'bg-blue-50 border-blue-200 text-blue-700'
                    }`}
                  >
                    <span className="text-2xl">🐑</span>
                    <span className="text-[10px] font-bold mt-0.5">{animal.id}</span>
                  </div>
                )}

                {/* Details */}
                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span
                        className={`px-2 py-0.5 rounded-lg text-xs font-black ${
                          animal.sex === 'female'
                            ? 'bg-pink-100 text-pink-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {animal.id}
                      </span>
                      <span className="text-xs font-bold text-stone-900 truncate">
                        {animal.sex === 'female' ? 'نعجة' : 'كبش'} · {animal.color}
                      </span>
                    </div>

                    {/* Status Badge */}
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        animal.status === 'healthy'
                          ? 'bg-emerald-100 text-emerald-800'
                          : animal.status === 'pregnant'
                          ? 'bg-amber-100 text-amber-800'
                          : animal.status === 'sick'
                          ? 'bg-red-100 text-red-800'
                          : animal.status === 'sold'
                          ? 'bg-stone-100 text-stone-700'
                          : 'bg-rose-200 text-rose-900'
                      }`}
                    >
                      {animal.status === 'healthy'
                        ? animal.sex === 'female' ? 'سليمة' : 'سليم'
                        : animal.status === 'pregnant'
                        ? 'حامل'
                        : animal.status === 'sick'
                        ? 'مريض'
                        : animal.status === 'sold'
                        ? 'مباع'
                        : 'نافق'}
                    </span>
                  </div>

                  {/* Age */}
                  <div className="text-[11px] text-emerald-800 font-semibold truncate">
                    العمر: {age}
                  </div>

                  {/* Source & Mother */}
                  <div className="text-[11px] text-stone-500 truncate flex items-center gap-1">
                    <span>{animal.source === 'purchase' ? 'شراء' : 'ولادة بالمزرعة'}</span>
                    {animal.motherId && <span>· الأم: {animal.motherId}</span>}
                    {animal.markings && <span>· {animal.markings}</span>}
                  </div>

                  {/* Pregnant badge if applicable */}
                  {isPregnant && (
                    <div className="flex items-center gap-1 text-[10px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md w-fit border border-amber-200">
                      <Heart size={11} className="fill-amber-600 text-amber-600" />
                      <span>حامل (قيد التوليد)</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button (+ إضافة رأس غنم) */}
      <button
        type="button"
        onClick={() => setIsAddModalOpen(true)}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-emerald-700 hover:bg-emerald-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-emerald-950/20 transition cursor-pointer"
        aria-label="تسجيل رأس غنم جديد"
      >
        <Plus size={18} />
        <span>إضافة رأس غنم</span>
      </button>

      {/* Modals */}
      <AnimalDetailModal
        animal={selectedAnimal}
        onClose={() => setSelectedAnimal(null)}
        onEdit={(a) => {
          setSelectedAnimal(null);
          setEditingAnimal(a);
        }}
        onRefresh={handleRefresh}
      />

      <AnimalFormModal
        isOpen={isAddModalOpen || !!editingAnimal}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingAnimal(null);
        }}
        onSave={handleRefresh}
        editingAnimal={editingAnimal}
      />
    </div>
  );
};
