import React, { useState } from 'react';
import {
  CreditCard,
  Plus,
  Filter,
  Trash2,
  Edit2,
  Calendar,
  X,
  Save,
  ArrowDownLeft,
  ChevronDown,
} from 'lucide-react';
import { ExpenseCategory, ExpenseRecord } from '../types';
import { SheepDB } from '../store/database';
import {
  centimesToDzd,
  formatCentimes,
  formatDateArabic,
  formatDzd,
  formatDualCurrency,
} from '../utils/formatters';
import { CurrencyInput } from '../components/CurrencyInput';

interface ExpensesViewProps {
  isAddModalOpenProp?: boolean;
  onCloseAddModalProp?: () => void;
}

const CATEGORY_LABELS: Record<ExpenseCategory, { label: string; icon: string; color: string }> = {
  livestock: { label: 'شراء المواشي', icon: '🐑', color: 'bg-emerald-100 text-emerald-800' },
  feed: { label: 'الأعلاف المركزة', icon: '🌾', color: 'bg-amber-100 text-amber-800' },
  hay_straw: { label: 'القرط والتبن', icon: '🚜', color: 'bg-yellow-100 text-yellow-800' },
  vet: { label: 'العلاج والبيطرة', icon: '🩺', color: 'bg-red-100 text-red-800' },
  vaccine: { label: 'التطعيمات واللقاحات', icon: '💉', color: 'bg-blue-100 text-blue-800' },
  transport: { label: 'النقل والمواصلات', icon: '🚚', color: 'bg-indigo-100 text-indigo-800' },
  equipment: { label: 'المعدات والأدوات', icon: '🛠️', color: 'bg-stone-100 text-stone-800' },
  other: { label: 'مصاريف أخرى', icon: '📝', color: 'bg-purple-100 text-purple-800' },
};

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  isAddModalOpenProp,
  onCloseAddModalProp,
}) => {
  const [filterCategory, setFilterCategory] = useState<'all' | ExpenseCategory>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<ExpenseRecord | null>(null);
  const [refreshKey, setRefreshKey] = useState(0);

  // Form inputs
  const [category, setCategory] = useState<ExpenseCategory>('feed');
  const [title, setTitle] = useState('');
  const [amountCentimes, setAmountCentimes] = useState(0);
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [notes, setNotes] = useState('');

  const expenses = SheepDB.getExpenses();
  const finance = SheepDB.getFinancialSummary();

  const isModalActive = isModalOpen || !!isAddModalOpenProp || !!editingExpense;

  const filtered = expenses.filter((e) => {
    if (filterCategory === 'all') return true;
    return e.category === filterCategory;
  });

  const handleOpenAdd = () => {
    setEditingExpense(null);
    setCategory('feed');
    setTitle('');
    setAmountCentimes(0);
    setDate(new Date().toISOString().split('T')[0]);
    setNotes('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (exp: ExpenseRecord) => {
    setEditingExpense(exp);
    setCategory(exp.category);
    setTitle(exp.title);
    setAmountCentimes(exp.amountCentimes);
    setDate(exp.date);
    setNotes(exp.notes || '');
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setEditingExpense(null);
    if (onCloseAddModalProp) onCloseAddModalProp();
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || amountCentimes <= 0) {
      alert('يرجى كتابة بيان المصروف وتحديد المبلغ');
      return;
    }

    if (editingExpense) {
      SheepDB.updateExpense({
        ...editingExpense,
        category,
        title,
        amountCentimes,
        amountDzd: centimesToDzd(amountCentimes),
        date,
        notes,
      });
    } else {
      SheepDB.addExpense({
        category,
        title,
        amountCentimes,
        amountDzd: centimesToDzd(amountCentimes),
        inputCurrency: 'centimes',
        date,
        notes,
      });
    }

    handleCloseModal();
    setRefreshKey((k) => k + 1);
  };

  const handleDelete = (id: string) => {
    if (confirm('هل أنت متأكد من حذف هذا المصروف؟')) {
      SheepDB.deleteExpense(id);
      setRefreshKey((k) => k + 1);
    }
  };

  return (
    <div className="space-y-3 pb-24">
      {/* Total Expenses Summary Banner */}
      <div className="bg-white rounded-2xl p-4 border border-stone-200/80 shadow-xs flex items-center justify-between">
        <div className="space-y-0.5">
          <div className="text-xs text-stone-500 font-semibold flex items-center gap-1">
            <ArrowDownLeft size={14} className="text-red-600" />
            <span>إجمالي المصاريف المسجلة:</span>
          </div>
          <div className="text-xl font-black text-red-700 tabular-nums">
            {formatDzd(finance.totalExpensesCentimes)}
          </div>
          <div className="text-[11px] text-stone-500 tabular-nums">
            يعادل: {formatCentimes(finance.totalExpensesCentimes)}
          </div>
        </div>

        <div className="text-left bg-stone-50 p-2.5 rounded-xl border border-stone-200 text-xs">
          <span className="text-stone-400 block text-[10px]">رأس المال المتبقي:</span>
          <span className="font-extrabold text-emerald-800 tabular-nums">
            {formatDzd(finance.remainingCapitalCentimes)}
          </span>
        </div>
      </div>

      {/* Filter Tabs by Category */}
      <div className="space-y-2 sticky top-[60px] z-20 bg-stone-50 pt-1 pb-2">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            type="button"
            onClick={() => setFilterCategory('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
              filterCategory === 'all'
                ? 'bg-red-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
            }`}
          >
            جميع المصاريف ({expenses.length})
          </button>
          {Object.entries(CATEGORY_LABELS).map(([catKey, info]) => {
            const count = expenses.filter((e) => e.category === catKey).length;
            if (count === 0 && filterCategory !== catKey) return null;
            return (
              <button
                key={catKey}
                type="button"
                onClick={() => setFilterCategory(catKey as ExpenseCategory)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition ${
                  filterCategory === catKey
                    ? 'bg-red-800 text-white shadow-xs'
                    : 'bg-white border border-stone-200 text-stone-600 hover:bg-stone-100'
                }`}
              >
                {info.label} ({count})
              </button>
            );
          })}
        </div>
      </div>

      {/* Expenses List */}
      {filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-stone-200 shadow-xs space-y-2">
          <CreditCard size={32} className="text-stone-300 mx-auto" />
          <p className="text-xs font-bold text-stone-700">لا توجد مصاريف مطابقة للتصفية</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((exp, idx) => {
            const catInfo = CATEGORY_LABELS[exp.category] || CATEGORY_LABELS.other;

            return (
              <div
                key={exp.id}
                className="bg-white rounded-2xl p-3.5 border border-stone-200/80 shadow-xs hover:border-red-300 transition flex items-center justify-between gap-3 relative"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 ${catInfo.color}`}
                  >
                    <span>{catInfo.icon}</span>
                  </div>

                  <div className="min-w-0">
                    <h3 className="font-bold text-stone-900 text-xs truncate">{exp.title}</h3>
                    <div className="text-[11px] text-stone-500 flex items-center gap-1.5 mt-0.5">
                      <span className="font-medium text-stone-600">{catInfo.label}</span>
                      <span>·</span>
                      <span>{formatDateArabic(exp.date)}</span>
                    </div>
                    {exp.notes && (
                      <p className="text-[10px] text-stone-400 truncate mt-0.5">{exp.notes}</p>
                    )}
                  </div>
                </div>

                {/* Amount in DZD + Centimes & Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-left">
                    <div className="font-black text-red-700 text-sm tabular-nums">
                      {formatDzd(exp.amountCentimes)}
                    </div>
                    <div className="text-[10px] text-stone-400 tabular-nums">
                      {formatCentimes(exp.amountCentimes)}
                    </div>
                  </div>

                  <div className="flex flex-col gap-1 mr-1">
                    <button
                      type="button"
                      onClick={() => handleOpenEdit(exp)}
                      className="p-1 rounded text-stone-400 hover:text-stone-700 hover:bg-stone-100"
                      title="تعديل"
                    >
                      <Edit2 size={13} />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDelete(exp.id)}
                      className="p-1 rounded text-stone-400 hover:text-red-600 hover:bg-red-50"
                      title="حذف"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Floating Action Button */}
      <button
        type="button"
        onClick={handleOpenAdd}
        className="fixed bottom-20 left-4 z-30 flex items-center gap-2 px-4 py-3 rounded-2xl bg-red-700 hover:bg-red-800 active:scale-95 text-white font-bold text-xs shadow-lg shadow-red-950/20 transition cursor-pointer"
      >
        <Plus size={18} />
        <span>تسجيل مصروف جديد</span>
      </button>

      {/* Add / Edit Expense Modal */}
      {isModalActive && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between px-5 py-3.5 bg-red-800 text-white">
              <h2 className="text-base font-bold">
                {editingExpense ? 'تعديل بيانات المصروف' : 'تسجيل مصروف جديد'}
              </h2>
              <button
                type="button"
                onClick={handleCloseModal}
                className="p-1 rounded-full text-white/80 hover:text-white"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSave} className="p-5 space-y-3.5 text-xs overflow-y-auto">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">تصنيف المصروف</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value as ExpenseCategory)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-semibold"
                >
                  {Object.entries(CATEGORY_LABELS).map(([key, info]) => (
                    <option key={key} value={key}>
                      {info.icon} {info.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  بيان المصروف (الوصف) <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="مثال: شراء شعير، نقل أعلاف، فحص بيطري، حجر ملح..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white font-medium"
                  required
                />
              </div>

              {/* Amount with DZD / Centimes toggle */}
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200">
                <CurrencyInput
                  label="مبلغ المصروف"
                  centimesValue={amountCentimes}
                  onChangeCentimes={setAmountCentimes}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">تاريخ المصروف</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">ملاحظات إضافية</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="مكان الشراء، رقم الفاتورة..."
                  className="w-full h-10 px-3 rounded-xl border border-stone-300 text-xs bg-white"
                />
              </div>

              <button
                type="submit"
                className="w-full h-12 rounded-xl bg-red-700 hover:bg-red-800 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
              >
                <Save size={18} />
                <span>{editingExpense ? 'حفظ التعديلات' : 'تسجيل وتحديث رأس المال'}</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
