import React, { useState } from 'react';
import { Smartphone, Download, Copy, Check, Code, FileText, FolderGit2 } from 'lucide-react';

interface AndroidFile {
  name: string;
  path: string;
  description: string;
  language: string;
  content: string;
}

const ANDROID_FILES: AndroidFile[] = [
  {
    name: 'AndroidManifest.xml',
    path: 'app/src/main/AndroidManifest.xml',
    description: 'ملف بيان الأندرويد، يدعم RTL وcom.mazraati.sheep بدون إنترنت',
    language: 'xml',
    content: `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.mazraati.sheep">

    <!-- كاميرا ومعرض الصور بدون الحاجة لاتصال بالإنترنت -->
    <uses-feature android:name="android.hardware.camera" android:required="false" />
    <uses-permission android:name="android.permission.CAMERA" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
    <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />

    <application
        android:name=".MazraatiApp"
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@style/Theme.MazraatiSheep">
        
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:theme="@style/Theme.MazraatiSheep">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`,
  },
  {
    name: 'build.gradle.kts',
    path: 'app/build.gradle.kts',
    description: 'إعدادات البناء والمكتبات: Room, Jetpack Compose, Material 3, ViewModel',
    language: 'kotlin',
    content: `plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {
    namespace = "com.mazraati.sheep"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mazraati.sheep"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    // Jetpack Compose & Material 3
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)
    implementation(libs.androidx.material.icons.extended)

    // Navigation & ViewModel
    implementation(libs.androidx.navigation.compose)
    implementation(libs.androidx.lifecycle.viewmodel.compose)

    // Room Database (حفظ محلي دائم بدون إنترنت)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
}`,
  },
  {
    name: 'AnimalEntity.kt',
    path: 'app/src/main/java/com/mazraati/sheep/data/AnimalEntity.kt',
    description: 'كيان قاعدة بيانات Room للأغنام مع تسلسل N.. وK..',
    language: 'kotlin',
    content: `package com.mazraati.sheep.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "animals")
data class AnimalEntity(
    @PrimaryKey
    val id: String, // Females: N 1, N 2... Males: K 1, K 2...
    val sex: String, // "female" or "male"
    val birthDate: String, // YYYY-MM-DD
    val source: String, // "purchase" or "farm_born"
    val color: String,
    val markings: String? = null,
    val photoUri: String? = null,
    val notes: String? = null,
    val status: String = "healthy", // "healthy", "pregnant", "sick", "sold", "dead"
    val motherId: String? = null,
    val fatherId: String? = null,
    val purchasePriceCentimes: Long? = null,
    val salePriceCentimes: Long? = null,
    val saleDate: String? = null,
    val deathDate: String? = null,
    val deathReason: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)`,
  },
  {
    name: 'ExpenseEntity.kt',
    path: 'app/src/main/java/com/mazraati/sheep/data/ExpenseEntity.kt',
    description: 'كيان المصاريف بالدينار الجزائري والسنتيم',
    language: 'kotlin',
    content: `package com.mazraati.sheep.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "expenses")
data class ExpenseEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val category: String, // livestock, feed, vet, vaccine, hay_straw, transport, equipment, other
    val title: String,
    val amountCentimes: Long, // Stored in centimes for 100% precision integer math
    val date: String, // YYYY-MM-DD
    val notes: String? = null,
    val animalId: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val amountDzd: Double
        get() = amountCentimes / 100.0
}`,
  },
  {
    name: 'SheepDao.kt',
    path: 'app/src/main/java/com/mazraati/sheep/data/SheepDao.kt',
    description: 'واجهة استعلامات Room DAO مع تدفقات Flow التفاعلية',
    language: 'kotlin',
    content: `package com.mazraati.sheep.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SheepDao {
    @Query("SELECT * FROM animals ORDER BY id ASC")
    fun getAllAnimals(): Flow<List<AnimalEntity>>

    @Query("SELECT * FROM animals WHERE id = :id")
    suspend fun getAnimalById(id: String): AnimalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAnimal(animal: AnimalEntity)

    @Update
    suspend fun updateAnimal(animal: AnimalEntity)

    @Query("DELETE FROM animals WHERE id = :id")
    suspend fun deleteAnimal(id: String)

    @Query("SELECT * FROM expenses ORDER BY date DESC")
    fun getAllExpenses(): Flow<List<ExpenseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExpense(expense: ExpenseEntity)

    @Query("SELECT SUM(amountCentimes) FROM expenses")
    fun getTotalExpensesCentimes(): Flow<Long?>
}`,
  },
  {
    name: 'SheepDatabase.kt',
    path: 'app/src/main/java/com/mazraati/sheep/data/SheepDatabase.kt',
    description: 'قاعدة بيانات Room مع إدراج المصاريف الـ14 التاريخية عند الإنشاء',
    language: 'kotlin',
    content: `package com.mazraati.sheep.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [AnimalEntity::class, ExpenseEntity::class], version = 1, exportSchema = false)
abstract class SheepDatabase : RoomDatabase() {
    abstract fun sheepDao(): SheepDao

    companion object {
        const val STARTING_CAPITAL_CENTIMES = 120_000_000L // 120 مليون سنتيم = 1,200,000 د.ج

        @Volatile
        private var INSTANCE: SheepDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): SheepDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SheepDatabase::class.java,
                    "mazraati_sheep_db"
                ).addCallback(DatabaseCallback(scope)).build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(private val scope: CoroutineScope) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        seedHistoricalData(database.sheepDao())
                    }
                }
            }

            suspend fun seedHistoricalData(dao: SheepDao) {
                // إدراج المصاريف التاريخية الـ 14 تماماً كما طُلب
                val initialExpenses = listOf(
                    ExpenseEntity(category = "livestock", title = "شراء 3 نعاج (الدفعة الأولى)", amountCentimes = 51_900_000, date = "2026-09-01"),
                    ExpenseEntity(category = "transport", title = "نقل ومواصلات", amountCentimes = 400_000, date = "2026-09-01"),
                    ExpenseEntity(category = "vet", title = "فحص بيطري", amountCentimes = 250_000, date = "2026-09-03"),
                    ExpenseEntity(category = "hay_straw", title = "80 بالة قرط وتبن", amountCentimes = 2_600_000, date = "2026-09-05"),
                    ExpenseEntity(category = "equipment", title = "غطاء بلاستيكي (باش)", amountCentimes = 400_000, date = "2026-09-06"),
                    ExpenseEntity(category = "vet", title = "حجر ملح ودواء البراغيث", amountCentimes = 250_000, date = "2026-09-08"),
                    ExpenseEntity(category = "equipment", title = "سياج وشبك حظيرة", amountCentimes = 200_000, date = "2026-09-10"),
                    ExpenseEntity(category = "feed", title = "نخالة", amountCentimes = 340_000, date = "2026-09-15"),
                    ExpenseEntity(category = "livestock", title = "شراء 3 نعاج إضافية", amountCentimes = 43_000_000, date = "2026-09-20"),
                    ExpenseEntity(category = "feed", title = "قنطارين علف مركب (سيكاليم)", amountCentimes = 1_000_000, date = "2026-09-22"),
                    ExpenseEntity(category = "livestock", title = "شراء كبش الفحل (K 1)", amountCentimes = 11_500_000, date = "2026-09-29"),
                    ExpenseEntity(category = "vet", title = "علاج الكبش", amountCentimes = 300_000, date = "2026-09-30"),
                    ExpenseEntity(category = "feed", title = "حجر ملح معدني", amountCentimes = 120_000, date = "2026-10-02"),
                    ExpenseEntity(category = "vaccine", title = "تطعيم بتاريخ 14 أكتوبر 2026", amountCentimes = 1_000_000, date = "2026-10-14")
                )
                initialExpenses.forEach { dao.insertExpense(it) }

                // إدراج النعاج وسجلات المواليد التاريخية
                dao.insertAnimal(AnimalEntity(id = "N 1", sex = "female", birthDate = "2024-03-15", source = "purchase", color = "بيضاء", notes = "النعجة 1: ولدت بتاريخ 3 سبتمبر 2026 ونفق الخروف"))
                dao.insertAnimal(AnimalEntity(id = "N 2", sex = "female", birthDate = "2024-04-10", source = "purchase", color = "بيضاء برأس أشقر", notes = "النعجة 2: ولدت بتاريخ 14 سبتمبر 2026 (أنثى N 7)"))
                dao.insertAnimal(AnimalEntity(id = "N 3", sex = "female", birthDate = "2024-05-02", source = "purchase", color = "بيضاء", notes = "النعجة 3: ولدت بتاريخ 17 سبتمبر 2026 (أنثى N 9)"))
                dao.insertAnimal(AnimalEntity(id = "N 4", sex = "female", birthDate = "2024-02-20", source = "purchase", color = "بيضاء", notes = "النعجة 4: ولدت بتاريخ 20 أكتوبر 2026 (خروف سليم حي K 2)"))
                dao.insertAnimal(AnimalEntity(id = "N 5", sex = "female", birthDate = "2024-06-12", source = "purchase", color = "بيضاء بوجه أسود", status = "pregnant", notes = "النعجة 5: تلقيح 24 أكتوبر 2026 ولادة متوقعة 20-22 مارس 2027"))
                dao.insertAnimal(AnimalEntity(id = "N 6", sex = "female", birthDate = "2024-07-05", source = "purchase", color = "بيضاء"))
                dao.insertAnimal(AnimalEntity(id = "N 7", sex = "female", birthDate = "2026-09-14", source = "farm_born", color = "بيضاء برأس أشقر", motherId = "N 2", notes = "مولودة النعجة 2"))
                dao.insertAnimal(AnimalEntity(id = "N 8", sex = "female", birthDate = "2023-10-10", source = "purchase", color = "بيضاء", notes = "النعجة 8: ولدت توأم بتاريخ 27 أبريل 2026"))
                dao.insertAnimal(AnimalEntity(id = "N 9", sex = "female", birthDate = "2026-09-17", source = "farm_born", color = "بيضاء", motherId = "N 3", notes = "مولودة النعجة 3"))
                dao.insertAnimal(AnimalEntity(id = "K 1", sex = "male", birthDate = "2023-11-15", source = "purchase", color = "أبيض بقرون كبيرة", notes = "كبش الفحل مشتري في 29 سبتمبر 2026"))
                dao.insertAnimal(AnimalEntity(id = "K 2", sex = "male", birthDate = "2026-10-20", source = "farm_born", color = "أبيض", motherId = "N 4", fatherId = "K 1", notes = "خروف سليم حي"))
            }
        }
    }
}`,
  },
  {
    name: 'DashboardScreen.kt',
    path: 'app/src/main/java/com/mazraati/sheep/ui/DashboardScreen.kt',
    description: 'واجهة Jetpack Compose للرئيسية بنسق Material 3 الأخضر الزراعي',
    language: 'kotlin',
    content: `package com.mazraati.sheep.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun DashboardScreen(
    remainingCapitalCentimes: Long,
    totalExpensesCentimes: Long,
    flockCount: Int,
    femaleCount: Int,
    maleCount: Int,
    onNavigateToAnimals: () -> Unit,
    onNavigateToExpenses: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF8FAF9))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // بطاقة رأس المال باللون الزراعي
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B4332))
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "رأس المال المتبقي في الصندوق",
                    color = Color(0xFFA7D7C5),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
                val remainingDzd = remainingCapitalCentimes / 100.0
                Text(
                    text = "%,.0f د.ج".format(remainingDzd),
                    color = Color.White,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "يعادل: %,d سنتيم".format(remainingCapitalCentimes),
                    color = Color(0xFFA7D7C5),
                    fontSize = 12.sp
                )
            }
        }

        // تعداد الأغنام
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            StatCard(modifier = Modifier.weight(1f), title = "إجمالي الحاضر", value = "$flockCount رأس", color = Color(0xFF2D6A4F))
            StatCard(modifier = Modifier.weight(1f), title = "النعاج (N)", value = "$femaleCount نعجة", color = Color(0xFFBE185D))
            StatCard(modifier = Modifier.weight(1f), title = "الكباش (K)", value = "$maleCount كبش", color = Color(0xFF1D4ED8))
        }
    }
}

@Composable
fun StatCard(modifier: Modifier = Modifier, title: String, value: String, color: Color) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(text = title, fontSize = 11.sp, color = Color.Gray)
            Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = color)
        }
    }
}`,
  },
];

export const AndroidCodeExportView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_FILES[0]);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = selectedFile.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 pb-24">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-900 to-[#1b4332] rounded-2xl p-4 text-white shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-600/60 border border-emerald-400/40 flex items-center justify-center">
            <Smartphone size={22} className="text-white" />
          </div>
          <div>
            <h2 className="text-sm font-bold">مشروع أندرويد الأصلي (Kotlin + Jetpack Compose)</h2>
            <p className="text-[11px] text-emerald-200">
              حزمة com.mazraati.sheep · بنية نظيفة Clean Architecture · قاعدة بيانات Room
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={handleDownloadFile}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-xs cursor-pointer transition"
          title="تنزيل الملف المختار"
        >
          <Download size={14} />
          <span className="hidden sm:inline">تحميل الملف</span>
        </button>
      </div>

      {/* File Selector Tabs */}
      <div className="flex gap-1.5 overflow-x-auto no-scrollbar py-0.5">
        {ANDROID_FILES.map((file) => (
          <button
            key={file.name}
            type="button"
            onClick={() => setSelectedFile(file)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition flex items-center gap-1.5 cursor-pointer ${
              selectedFile.name === file.name
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white border border-stone-200 text-stone-700 hover:bg-stone-50'
            }`}
          >
            <FileText size={13} />
            <span>{file.name}</span>
          </button>
        ))}
      </div>

      {/* Code Viewer Card */}
      <div className="bg-[#1e293b] text-slate-100 rounded-2xl overflow-hidden shadow-md border border-slate-700/60 font-mono text-xs">
        {/* Code Header */}
        <div className="bg-slate-900/90 px-4 py-2.5 flex items-center justify-between border-b border-slate-700/50">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
            <span className="text-[11px] text-slate-400 mr-2 ltr">{selectedFile.path}</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopy}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-sans font-medium transition cursor-pointer"
            >
              {copied ? <Check size={13} className="text-emerald-400" /> : <Copy size={13} />}
              <span>{copied ? 'تم النسخ!' : 'نسخ الكود'}</span>
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="p-4 overflow-x-auto max-h-[500px] leading-relaxed text-[11px] text-slate-200 ltr select-text">
          <pre>{selectedFile.content}</pre>
        </div>
      </div>

      {/* Explanation Banner */}
      <div className="p-4 rounded-2xl bg-stone-100 text-xs text-stone-700 space-y-1 border border-stone-200">
        <span className="font-bold block text-stone-900">
          دليل فتح المشروع في Android Studio:
        </span>
        <p className="leading-relaxed">
          1. افتح Android Studio وأنشئ مشروعاً جديداً باسم <strong>مزرعتي للأغنام</strong> وحزمة{' '}
          <strong>com.mazraati.sheep</strong> مع قالب Empty Compose Activity.
          <br />
          2. أضف كيانات Room ومكتبة Kotlin KSP كما هو موضح في الملفات أعلاه.
          <br />
          3. يعمل التطبيق محلياً وبشكل دائم بدون إنترنت 100% مع حسابات الدينار الجزائري ورأس المال
          الأولي (120 مليون سنتيم).
        </p>
      </div>
    </div>
  );
};
