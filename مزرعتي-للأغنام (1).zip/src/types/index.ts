/**
 * Mazraati Sheep (مزرعتي للأغنام) - Type Definitions
 * Native Android data models matching Room DB entities
 */

export type AnimalSex = 'female' | 'male';
export type AnimalStatus = 'healthy' | 'pregnant' | 'sick' | 'sold' | 'dead';
export type AnimalSource = 'purchase' | 'farm_born';

export interface Animal {
  id: string; // Females: N 1, N 2... Males: K 1, K 2...
  sex: AnimalSex;
  birthDate: string; // YYYY-MM-DD
  source: AnimalSource;
  color: string;
  markings?: string;
  photo?: string;
  notes?: string;
  status: AnimalStatus;
  motherId?: string | null;
  fatherId?: string | null;
  purchasePriceCentimes?: number;
  salePriceCentimes?: number;
  saleDate?: string;
  deathDate?: string;
  deathReason?: string;
  createdAt: string;
  updatedAt: string;
}

export type GestationStatus = 'pregnant' | 'delivered' | 'aborted';
export type NewbornCondition = 'alive' | 'weak' | 'dead';

export interface NewbornDetail {
  id: string;
  sex: AnimalSex;
  birthWeightKg: number;
  color: string;
  condition: NewbornCondition;
  photo?: string;
  registeredAnimalId?: string;
}

export interface BreedingRecord {
  id: string;
  motherId: string; // N 1, N 2...
  ramId: string; // K 1...
  matingDate: string; // YYYY-MM-DD
  expectedLambingDate: string; // Mating + ~148 days
  actualLambingDate?: string | null;
  status: GestationStatus;
  newbornCount: number;
  newborns: NewbornDetail[];
  notes?: string;
  photo?: string;
  createdAt: string;
}

export type HealthRecordType = 'treatment' | 'vaccination' | 'vet_visit' | 'checkup';

export interface HealthRecord {
  id: string;
  animalId: string; // ID or 'all' for flock
  type: HealthRecordType;
  diseaseOrSymptom: string;
  vetName?: string;
  medication: string;
  dosage?: string;
  treatmentDate: string; // YYYY-MM-DD
  nextReminderDate?: string | null;
  costCentimes?: number;
  notes?: string;
  photo?: string;
  createdAt: string;
}

export type FeedType = 'barley' | 'bran' | 'corn' | 'hay' | 'straw' | 'mixed' | 'other';
export type FeedUnit = 'quintal' | 'bale' | 'kg' | 'bag';
export type TargetGroup = 'all' | 'females' | 'males' | 'pregnant' | 'lambs';

export interface FeedItem {
  id: string;
  feedType: FeedType;
  name: string;
  dailyRationGrams: number; // Daily ration per head
  targetGroup: TargetGroup;
  stockQuantityKg: number;
  pricePerUnitCentimes: number;
  unitType: FeedUnit;
  unitWeightKg: number; // e.g. 100 for quintal, 20 for bale
  notes?: string;
  lastUpdated: string;
}

export type ExpenseCategory =
  | 'livestock'
  | 'feed'
  | 'vet'
  | 'vaccine'
  | 'hay_straw'
  | 'transport'
  | 'equipment'
  | 'other';

export interface ExpenseRecord {
  id: string;
  category: ExpenseCategory;
  title: string;
  amountCentimes: number;
  amountDzd: number;
  inputCurrency: 'centimes' | 'dzd';
  date: string; // YYYY-MM-DD
  notes?: string;
  animalId?: string;
  createdAt: string;
}

export type IncomeCategory = 'animal_sale' | 'lamb_sale' | 'wool_milk' | 'manure' | 'other';

export interface IncomeRecord {
  id: string;
  category: IncomeCategory;
  title: string;
  amountCentimes: number;
  amountDzd: number;
  inputCurrency: 'centimes' | 'dzd';
  date: string; // YYYY-MM-DD
  animalId?: string;
  notes?: string;
  createdAt: string;
}

export type ReminderCategory = 'lambing' | 'mating' | 'vaccination' | 'treatment' | 'feed' | 'custom';
export type ReminderPriority = 'high' | 'normal' | 'low';

export interface ReminderItem {
  id: string;
  title: string;
  category: ReminderCategory;
  targetDate: string; // YYYY-MM-DD
  animalId?: string;
  notes?: string;
  isCompleted: boolean;
  priority: ReminderPriority;
  createdAt: string;
}

export interface AppSettings {
  startingCapitalCentimes: number; // 120,000,000 centimes = 1,200,000 DZD
  currencyDisplay: 'both' | 'centimes' | 'dzd';
  lastFemaleSequence: number;
  lastMaleSequence: number;
  isSeeded: boolean;
}

export type NavigationSection =
  | 'dashboard'
  | 'animals'
  | 'reproduction'
  | 'health'
  | 'feeding'
  | 'expenses'
  | 'income'
  | 'reports'
  | 'reminders'
  | 'backup'
  | 'android_code';
