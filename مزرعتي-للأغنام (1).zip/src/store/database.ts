import {
  Animal,
  AppSettings,
  BreedingRecord,
  ExpenseRecord,
  FeedItem,
  HealthRecord,
  IncomeRecord,
  ReminderItem,
} from '../types';
import { calculateExpectedLambing, centimesToDzd, dzdToCentimes } from '../utils/formatters';
import {
  INITIAL_ANIMALS,
  INITIAL_BREEDINGS,
  INITIAL_EXPENSES,
  INITIAL_FEEDS,
  INITIAL_HEALTH,
  INITIAL_INCOME,
  INITIAL_REMINDERS,
  INITIAL_SETTINGS,
} from './initialData';

const DB_KEYS = {
  SETTINGS: 'mazraati_settings_v2',
  ANIMALS: 'mazraati_animals_v2',
  BREEDINGS: 'mazraati_breedings_v2',
  HEALTH: 'mazraati_health_v2',
  FEEDS: 'mazraati_feeds_v2',
  EXPENSES: 'mazraati_expenses_v2',
  INCOME: 'mazraati_income_v2',
  REMINDERS: 'mazraati_reminders_v2',
};

// Safe local storage helpers
function readStorage<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : defaultValue;
  } catch (error) {
    console.error(`Error reading ${key} from storage:`, error);
    return defaultValue;
  }
}

function writeStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (error) {
    console.error(`Error writing ${key} to storage:`, error);
  }
}

/**
 * Initialize Database with Seed Data if first run
 */
export function initializeDatabase(): void {
  const settings = readStorage<AppSettings | null>(DB_KEYS.SETTINGS, null);
  if (!settings || !settings.isSeeded) {
    writeStorage(DB_KEYS.SETTINGS, INITIAL_SETTINGS);
    writeStorage(DB_KEYS.ANIMALS, INITIAL_ANIMALS);
    writeStorage(DB_KEYS.BREEDINGS, INITIAL_BREEDINGS);
    writeStorage(DB_KEYS.HEALTH, INITIAL_HEALTH);
    writeStorage(DB_KEYS.FEEDS, INITIAL_FEEDS);
    writeStorage(DB_KEYS.EXPENSES, INITIAL_EXPENSES);
    writeStorage(DB_KEYS.INCOME, INITIAL_INCOME);
    writeStorage(DB_KEYS.REMINDERS, INITIAL_REMINDERS);
  }
}

// Ensure database is initialized immediately
initializeDatabase();

export const SheepDB = {
  // ================= SETTINGS =================
  getSettings(): AppSettings {
    return readStorage<AppSettings>(DB_KEYS.SETTINGS, INITIAL_SETTINGS);
  },

  updateSettings(partial: Partial<AppSettings>): AppSettings {
    const current = this.getSettings();
    const updated = { ...current, ...partial };
    writeStorage(DB_KEYS.SETTINGS, updated);
    return updated;
  },

  // ================= ANIMALS =================
  getAnimals(): Animal[] {
    return readStorage<Animal[]>(DB_KEYS.ANIMALS, []);
  },

  getAnimalById(id: string): Animal | undefined {
    return this.getAnimals().find((a) => a.id === id);
  },

  /**
   * Generates next unique ID:
   * Females: N 1, N 2, N 3...
   * Males: K 1, K 2, K 3...
   * Sequences are never reused!
   */
  generateAnimalId(sex: 'female' | 'male'): { id: string; sequence: number } {
    const settings = this.getSettings();
    if (sex === 'female') {
      const nextSeq = (settings.lastFemaleSequence || 0) + 1;
      this.updateSettings({ lastFemaleSequence: nextSeq });
      return { id: `N ${nextSeq}`, sequence: nextSeq };
    } else {
      const nextSeq = (settings.lastMaleSequence || 0) + 1;
      this.updateSettings({ lastMaleSequence: nextSeq });
      return { id: `K ${nextSeq}`, sequence: nextSeq };
    }
  },

  addAnimal(data: Omit<Animal, 'id' | 'createdAt' | 'updatedAt'> & { customId?: string }): Animal {
    const animals = this.getAnimals();
    let id = data.customId?.trim();

    if (!id) {
      const generated = this.generateAnimalId(data.sex);
      id = generated.id;
    }

    const now = new Date().toISOString();
    const newAnimal: Animal = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };

    animals.unshift(newAnimal);
    writeStorage(DB_KEYS.ANIMALS, animals);

    // If it has purchase price, auto record expense if requested
    if (data.source === 'purchase' && data.purchasePriceCentimes && data.purchasePriceCentimes > 0) {
      this.addExpense({
        category: 'livestock',
        title: `شراء رأس غنم (${newAnimal.id})`,
        amountCentimes: data.purchasePriceCentimes,
        amountDzd: centimesToDzd(data.purchasePriceCentimes),
        inputCurrency: 'centimes',
        date: data.birthDate || now.split('T')[0],
        animalId: newAnimal.id,
        notes: `شراء ${newAnimal.sex === 'female' ? 'نعجة' : 'كبش'} برقم تعريفي ${newAnimal.id}`,
      });
    }

    return newAnimal;
  },

  updateAnimal(animal: Animal): void {
    const animals = this.getAnimals();
    const index = animals.findIndex((a) => a.id === animal.id);
    if (index !== -1) {
      animals[index] = { ...animal, updatedAt: new Date().toISOString() };
      writeStorage(DB_KEYS.ANIMALS, animals);
    }
  },

  deleteAnimal(id: string): void {
    const animals = this.getAnimals().filter((a) => a.id !== id);
    writeStorage(DB_KEYS.ANIMALS, animals);
  },

  markAnimalSold(id: string, salePriceCentimes: number, saleDate: string, notes?: string): void {
    const animal = this.getAnimalById(id);
    if (!animal) return;

    this.updateAnimal({
      ...animal,
      status: 'sold',
      salePriceCentimes,
      saleDate,
      notes: notes ? `${animal.notes || ''}\n[تم البيع]: ${notes}` : animal.notes,
    });

    // Record Income
    this.addIncome({
      category: 'animal_sale',
      title: `بيع رأس غنم (${animal.id})`,
      amountCentimes: salePriceCentimes,
      amountDzd: centimesToDzd(salePriceCentimes),
      inputCurrency: 'centimes',
      date: saleDate,
      animalId: animal.id,
      notes: notes || `بيع ${animal.sex === 'female' ? 'النعجة' : 'الكبش'} ${animal.id}`,
    });
  },

  markAnimalDead(id: string, deathDate: string, deathReason: string): void {
    const animal = this.getAnimalById(id);
    if (!animal) return;

    this.updateAnimal({
      ...animal,
      status: 'dead',
      deathDate,
      deathReason,
    });
  },

  // ================= BREEDING & BIRTHS =================
  getBreedings(): BreedingRecord[] {
    return readStorage<BreedingRecord[]>(DB_KEYS.BREEDINGS, []);
  },

  addBreeding(
    data: Omit<BreedingRecord, 'id' | 'createdAt' | 'expectedLambingDate'> & {
      expectedLambingDate?: string;
    }
  ): BreedingRecord {
    const breedings = this.getBreedings();
    const id = `br-${Date.now()}`;
    const expected = data.expectedLambingDate || calculateExpectedLambing(data.matingDate);

    const record: BreedingRecord = {
      ...data,
      id,
      expectedLambingDate: expected,
      createdAt: new Date().toISOString(),
    };

    breedings.unshift(record);
    writeStorage(DB_KEYS.BREEDINGS, breedings);

    // Auto add reminder for expected lambing
    if (record.status === 'pregnant' && expected) {
      this.addReminder({
        title: `موعد ولادة متوقع للنعجة ${record.motherId}`,
        category: 'lambing',
        targetDate: expected,
        animalId: record.motherId,
        notes: `تلقيح بتاريخ ${record.matingDate} مع الكبش ${record.ramId}`,
        priority: 'high',
      });
    }

    return record;
  },

  updateBreeding(record: BreedingRecord): void {
    const breedings = this.getBreedings();
    const index = breedings.findIndex((b) => b.id === record.id);
    if (index !== -1) {
      breedings[index] = record;
      writeStorage(DB_KEYS.BREEDINGS, breedings);
    }
  },

  deleteBreeding(id: string): void {
    const breedings = this.getBreedings().filter((b) => b.id !== id);
    writeStorage(DB_KEYS.BREEDINGS, breedings);
  },

  // ================= HEALTH & TREATMENTS =================
  getHealthRecords(): HealthRecord[] {
    return readStorage<HealthRecord[]>(DB_KEYS.HEALTH, []);
  },

  addHealthRecord(
    data: Omit<HealthRecord, 'id' | 'createdAt'> & { recordAsExpense?: boolean }
  ): HealthRecord {
    const records = this.getHealthRecords();
    const id = `hl-${Date.now()}`;
    const newRecord: HealthRecord = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };

    records.unshift(newRecord);
    writeStorage(DB_KEYS.HEALTH, records);

    // Auto add reminder if next reminder date set
    if (data.nextReminderDate) {
      this.addReminder({
        title: `تذكير صحي: ${data.diseaseOrSymptom} (${data.animalId === 'all' ? 'كامل القطيع' : data.animalId})`,
        category: data.type === 'vaccination' ? 'vaccination' : 'treatment',
        targetDate: data.nextReminderDate,
        animalId: data.animalId,
        notes: `متابعة علاج: ${data.medication || ''}`,
        priority: 'normal',
      });
    }

    // Auto record as expense if requested and cost > 0
    if (data.recordAsExpense && data.costCentimes && data.costCentimes > 0) {
      this.addExpense({
        category: data.type === 'vaccination' ? 'vaccine' : 'vet',
        title: `${data.type === 'vaccination' ? 'تطعيم' : 'علاج بيطري'}: ${data.diseaseOrSymptom}`,
        amountCentimes: data.costCentimes,
        amountDzd: centimesToDzd(data.costCentimes),
        inputCurrency: 'centimes',
        date: data.treatmentDate,
        animalId: data.animalId,
        notes: `دواء: ${data.medication || 'غير محدد'} | طبيب: ${data.vetName || 'غير محدد'}`,
      });
    }

    return newRecord;
  },

  updateHealthRecord(record: HealthRecord): void {
    const records = this.getHealthRecords();
    const index = records.findIndex((r) => r.id === record.id);
    if (index !== -1) {
      records[index] = record;
      writeStorage(DB_KEYS.HEALTH, records);
    }
  },

  deleteHealthRecord(id: string): void {
    const records = this.getHealthRecords().filter((r) => r.id !== id);
    writeStorage(DB_KEYS.HEALTH, records);
  },

  // ================= FEED MANAGEMENT =================
  getFeeds(): FeedItem[] {
    return readStorage<FeedItem[]>(DB_KEYS.FEEDS, []);
  },

  addFeed(data: Omit<FeedItem, 'id' | 'lastUpdated'>): FeedItem {
    const feeds = this.getFeeds();
    const newFeed: FeedItem = {
      ...data,
      id: `feed-${Date.now()}`,
      lastUpdated: new Date().toISOString(),
    };
    feeds.unshift(newFeed);
    writeStorage(DB_KEYS.FEEDS, feeds);
    return newFeed;
  },

  updateFeed(feed: FeedItem): void {
    const feeds = this.getFeeds();
    const index = feeds.findIndex((f) => f.id === feed.id);
    if (index !== -1) {
      feeds[index] = { ...feed, lastUpdated: new Date().toISOString() };
      writeStorage(DB_KEYS.FEEDS, feeds);
    }
  },

  deleteFeed(id: string): void {
    const feeds = this.getFeeds().filter((f) => f.id !== id);
    writeStorage(DB_KEYS.FEEDS, feeds);
  },

  // ================= EXPENSES =================
  getExpenses(): ExpenseRecord[] {
    return readStorage<ExpenseRecord[]>(DB_KEYS.EXPENSES, []);
  },

  addExpense(data: Omit<ExpenseRecord, 'id' | 'createdAt'>): ExpenseRecord {
    const expenses = this.getExpenses();
    const newExpense: ExpenseRecord = {
      ...data,
      id: `exp-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    expenses.unshift(newExpense);
    writeStorage(DB_KEYS.EXPENSES, expenses);
    return newExpense;
  },

  updateExpense(expense: ExpenseRecord): void {
    const expenses = this.getExpenses();
    const index = expenses.findIndex((e) => e.id === expense.id);
    if (index !== -1) {
      expenses[index] = expense;
      writeStorage(DB_KEYS.EXPENSES, expenses);
    }
  },

  deleteExpense(id: string): void {
    const expenses = this.getExpenses().filter((e) => e.id !== id);
    writeStorage(DB_KEYS.EXPENSES, expenses);
  },

  // ================= INCOME =================
  getIncome(): IncomeRecord[] {
    return readStorage<IncomeRecord[]>(DB_KEYS.INCOME, []);
  },

  addIncome(data: Omit<IncomeRecord, 'id' | 'createdAt'>): IncomeRecord {
    const income = this.getIncome();
    const newIncome: IncomeRecord = {
      ...data,
      id: `inc-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    income.unshift(newIncome);
    writeStorage(DB_KEYS.INCOME, income);
    return newIncome;
  },

  updateIncome(record: IncomeRecord): void {
    const income = this.getIncome();
    const index = income.findIndex((i) => i.id === record.id);
    if (index !== -1) {
      income[index] = record;
      writeStorage(DB_KEYS.INCOME, income);
    }
  },

  deleteIncome(id: string): void {
    const income = this.getIncome().filter((i) => i.id !== id);
    writeStorage(DB_KEYS.INCOME, income);
  },

  // ================= REMINDERS =================
  getReminders(): ReminderItem[] {
    return readStorage<ReminderItem[]>(DB_KEYS.REMINDERS, []);
  },

  addReminder(data: Omit<ReminderItem, 'id' | 'createdAt' | 'isCompleted'>): ReminderItem {
    const reminders = this.getReminders();
    const newReminder: ReminderItem = {
      ...data,
      id: `rem-${Date.now()}`,
      isCompleted: false,
      createdAt: new Date().toISOString(),
    };
    reminders.unshift(newReminder);
    writeStorage(DB_KEYS.REMINDERS, reminders);
    return newReminder;
  },

  toggleReminder(id: string): void {
    const reminders = this.getReminders();
    const index = reminders.findIndex((r) => r.id === id);
    if (index !== -1) {
      reminders[index].isCompleted = !reminders[index].isCompleted;
      writeStorage(DB_KEYS.REMINDERS, reminders);
    }
  },

  updateReminder(reminder: ReminderItem): void {
    const reminders = this.getReminders();
    const index = reminders.findIndex((r) => r.id === reminder.id);
    if (index !== -1) {
      reminders[index] = reminder;
      writeStorage(DB_KEYS.REMINDERS, reminders);
    }
  },

  deleteReminder(id: string): void {
    const reminders = this.getReminders().filter((r) => r.id !== id);
    writeStorage(DB_KEYS.REMINDERS, reminders);
  },

  // ================= SUMMARIES & CALCULATIONS =================
  getFinancialSummary() {
    const settings = this.getSettings();
    const expenses = this.getExpenses();
    const income = this.getIncome();

    const startingCapitalCentimes = settings.startingCapitalCentimes || 120_000_000;
    const totalExpensesCentimes = expenses.reduce((acc, curr) => acc + (curr.amountCentimes || 0), 0);
    const totalIncomeCentimes = income.reduce((acc, curr) => acc + (curr.amountCentimes || 0), 0);

    const remainingCapitalCentimes = startingCapitalCentimes - totalExpensesCentimes + totalIncomeCentimes;
    const netProfitCentimes = totalIncomeCentimes - totalExpensesCentimes;

    return {
      startingCapitalCentimes,
      startingCapitalDzd: centimesToDzd(startingCapitalCentimes),
      totalExpensesCentimes,
      totalExpensesDzd: centimesToDzd(totalExpensesCentimes),
      totalIncomeCentimes,
      totalIncomeDzd: centimesToDzd(totalIncomeCentimes),
      remainingCapitalCentimes,
      remainingCapitalDzd: centimesToDzd(remainingCapitalCentimes),
      netProfitCentimes,
      netProfitDzd: centimesToDzd(netProfitCentimes),
    };
  },

  getFlockSummary() {
    const animals = this.getAnimals();
    const breedings = this.getBreedings();

    // Present animals are those not sold and not dead (healthy, pregnant, sick)
    const presentAnimals = animals.filter(
      (a) => a.status === 'healthy' || a.status === 'pregnant' || a.status === 'sick'
    );
    const femalesCount = presentAnimals.filter((a) => a.sex === 'female').length;
    const malesCount = presentAnimals.filter((a) => a.sex === 'male').length;
    
    // Pregnant ewes (either marked as pregnant or has active pregnancy breeding record)
    const activePregnantBreedings = breedings.filter((b) => b.status === 'pregnant');
    const pregnantAnimalIds = new Set([
      ...animals.filter((a) => a.status === 'pregnant').map((a) => a.id),
      ...activePregnantBreedings.map((b) => b.motherId),
    ]);
    const pregnantEwesCount = pregnantAnimalIds.size;
    const expectedBirthsCount = activePregnantBreedings.length > 0 ? activePregnantBreedings.length : pregnantEwesCount;

    return {
      totalPresent: presentAnimals.length,
      femalesCount,
      malesCount,
      pregnantEwesCount,
      expectedBirthsCount,
      healthyCount: presentAnimals.filter((a) => a.status === 'healthy').length,
      sickCount: presentAnimals.filter((a) => a.status === 'sick').length,
      soldCount: animals.filter((a) => a.status === 'sold').length,
      deadCount: animals.filter((a) => a.status === 'dead').length,
    };
  },

  // ================= BACKUP & RESTORE =================
  exportBackupJson(): string {
    const backup = {
      version: 1,
      appName: 'Mazraati Sheep (مزرعتي للأغنام)',
      exportDate: new Date().toISOString(),
      settings: this.getSettings(),
      animals: this.getAnimals(),
      breedings: this.getBreedings(),
      health: this.getHealthRecords(),
      feeds: this.getFeeds(),
      expenses: this.getExpenses(),
      income: this.getIncome(),
      reminders: this.getReminders(),
    };
    return JSON.stringify(backup, null, 2);
  },

  importBackupJson(jsonString: string): { success: boolean; message: string } {
    try {
      const data = JSON.parse(jsonString);
      if (!data.settings || !data.animals) {
        return { success: false, message: 'ملف النسخة الاحتياطية غير صالح أو ناقص.' };
      }

      writeStorage(DB_KEYS.SETTINGS, data.settings);
      writeStorage(DB_KEYS.ANIMALS, data.animals || []);
      writeStorage(DB_KEYS.BREEDINGS, data.breedings || []);
      writeStorage(DB_KEYS.HEALTH, data.health || []);
      writeStorage(DB_KEYS.FEEDS, data.feeds || []);
      writeStorage(DB_KEYS.EXPENSES, data.expenses || []);
      writeStorage(DB_KEYS.INCOME, data.income || []);
      writeStorage(DB_KEYS.REMINDERS, data.reminders || []);

      return { success: true, message: 'تم استعادة النسخة الاحتياطية بنجاح.' };
    } catch (e) {
      return { success: false, message: 'تعذر قراءة ملف النسخة الاحتياطية (تنسيق غير سليم).' };
    }
  },

  resetToInitialData(): void {
    writeStorage(DB_KEYS.SETTINGS, INITIAL_SETTINGS);
    writeStorage(DB_KEYS.ANIMALS, INITIAL_ANIMALS);
    writeStorage(DB_KEYS.BREEDINGS, INITIAL_BREEDINGS);
    writeStorage(DB_KEYS.HEALTH, INITIAL_HEALTH);
    writeStorage(DB_KEYS.FEEDS, INITIAL_FEEDS);
    writeStorage(DB_KEYS.EXPENSES, INITIAL_EXPENSES);
    writeStorage(DB_KEYS.INCOME, INITIAL_INCOME);
    writeStorage(DB_KEYS.REMINDERS, INITIAL_REMINDERS);
  },
};
