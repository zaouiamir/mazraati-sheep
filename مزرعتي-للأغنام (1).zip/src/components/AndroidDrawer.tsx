import React from 'react';
import {
  Home,
  Layers,
  Heart,
  Activity,
  Wheat,
  CreditCard,
  TrendingUp,
  BarChart3,
  Bell,
  Settings,
  X,
  Smartphone,
  CheckCircle2,
} from 'lucide-react';
import { NavigationSection } from '../types';

interface AndroidDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  currentSection: NavigationSection;
  onSelectSection: (section: NavigationSection) => void;
  unreadRemindersCount: number;
}

interface NavItem {
  id: NavigationSection;
  label: string;
  sublabel: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  badge?: number;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: '1. الرئيسية', sublabel: 'إحصائيات ورأس المال', icon: Home },
  { id: 'animals', label: '2. الحيوانات', sublabel: 'سجل الأغنام والترقيم', icon: Layers },
  { id: 'reproduction', label: '3. الولادات والتلقيح', sublabel: 'متابعة الحمل والمواليد', icon: Heart },
  { id: 'health', label: '4. الصحة والعلاج', sublabel: 'الأدوية والبيطرة واللقاحات', icon: Activity },
  { id: 'feeding', label: '5. التغذية والأعلاف', sublabel: 'الوجبات والشعير والقرط', icon: Wheat },
  { id: 'expenses', label: '6. المصاريف', sublabel: 'سجل التكاليف والمشتريات', icon: CreditCard },
  { id: 'income', label: '7. المداخيل', sublabel: 'مبيعات الأغنام والأرباح', icon: TrendingUp },
  { id: 'reports', label: '8. التقارير', sublabel: 'كشوفات الأرباح والتحليل', icon: BarChart3 },
  { id: 'reminders', label: '9. التذكيرات', sublabel: 'مواعيد الولادات واللقاحات', icon: Bell },
  { id: 'backup', label: '10. النسخ الاحتياطي والإعدادات', sublabel: 'حفظ واستعادة البيانات', icon: Settings },
  { id: 'android_code', label: 'مشروع أندرويد ستوديو', sublabel: 'كود Kotlin + Jetpack Compose', icon: Smartphone },
];

export const AndroidDrawer: React.FC<AndroidDrawerProps> = ({
  isOpen,
  onClose,
  currentSection,
  onSelectSection,
  unreadRemindersCount,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Drawer Container (RTL: slides in from right) */}
      <div className="relative w-80 max-w-[85vw] h-full bg-white flex flex-col shadow-2xl z-10 animate-in slide-in-from-right duration-200">
        {/* Drawer Header with Agriculture Green Theme */}
        <div className="bg-[#1b4332] text-white p-5 pt-7 pb-6 relative">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 left-4 p-1.5 rounded-full hover:bg-white/10 active:bg-white/20 transition cursor-pointer text-white"
            aria-label="إغلاق القائمة"
          >
            <X size={20} />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600/60 border border-emerald-400/40 flex items-center justify-center shadow-inner overflow-hidden">
              <img src="/icon.svg" alt="شعار المزرعة" className="w-10 h-10 object-contain" />
            </div>
            <div>
              <h2 className="text-lg font-bold leading-tight">مزرعتي للأغنام</h2>
              <p className="text-xs text-emerald-200/80">com.mazraati.sheep</p>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-2 text-xs text-emerald-100 bg-emerald-900/40 px-3 py-1.5 rounded-xl border border-emerald-500/20">
            <CheckCircle2 size={14} className="text-emerald-400 shrink-0" />
            <span>يعمل بدون إنترنت 100% · حفظ محلي دائم</span>
          </div>
        </div>

        {/* Scrollable Navigation List */}
        <div className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            const isSpecial = item.id === 'android_code';

            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectSection(item.id);
                  onClose();
                }}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl text-right transition cursor-pointer min-h-[50px] ${
                  isActive
                    ? 'bg-emerald-50 text-emerald-900 font-bold border border-emerald-200 shadow-xs'
                    : isSpecial
                    ? 'bg-amber-50/60 text-amber-950 font-semibold border border-amber-200/60 hover:bg-amber-50'
                    : 'text-stone-700 hover:bg-stone-50 active:bg-stone-100'
                }`}
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${
                      isActive
                        ? 'bg-emerald-700 text-white shadow-xs'
                        : isSpecial
                        ? 'bg-amber-600 text-white'
                        : 'bg-stone-100 text-stone-600'
                    }`}
                  >
                    <Icon size={18} />
                  </div>
                  <div className="truncate">
                    <div className="text-sm leading-tight truncate">{item.label}</div>
                    <div className="text-[11px] text-stone-400 font-normal leading-tight truncate">
                      {item.sublabel}
                    </div>
                  </div>
                </div>

                {item.id === 'reminders' && unreadRemindersCount > 0 && (
                  <span className="min-w-[20px] h-[20px] flex items-center justify-center bg-red-500 text-white text-[11px] font-bold rounded-full px-1.5 shadow-xs">
                    {unreadRemindersCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Drawer Footer */}
        <div className="p-3 border-t border-stone-200 text-center bg-stone-50">
          <p className="text-[11px] text-stone-500 font-medium">
            تطبيق مزرعتي للأغنام © 2026 · بالدينار الجزائري
          </p>
        </div>
      </div>
    </div>
  );
};
