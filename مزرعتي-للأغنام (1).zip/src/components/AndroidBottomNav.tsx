import React from 'react';
import { Home, Layers, CreditCard, TrendingUp, Menu } from 'lucide-react';
import { NavigationSection } from '../types';

interface AndroidBottomNavProps {
  currentSection: NavigationSection;
  onSelectSection: (section: NavigationSection) => void;
  onOpenDrawer: () => void;
}

export const AndroidBottomNav: React.FC<AndroidBottomNavProps> = ({
  currentSection,
  onSelectSection,
  onOpenDrawer,
}) => {
  const tabs = [
    { id: 'dashboard' as NavigationSection, label: 'الرئيسية', icon: Home },
    { id: 'animals' as NavigationSection, label: 'الحيوانات', icon: Layers },
    { id: 'expenses' as NavigationSection, label: 'المصاريف', icon: CreditCard },
    { id: 'income' as NavigationSection, label: 'المداخيل', icon: TrendingUp },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-stone-200/80 shadow-[0_-2px_10px_rgba(0,0,0,0.05)] select-none">
      <div className="max-w-md mx-auto grid grid-cols-5 items-center h-16 px-1">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentSection === tab.id;

          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onSelectSection(tab.id)}
              className="flex flex-col items-center justify-center h-full py-1 text-center group cursor-pointer transition min-h-[48px]"
            >
              <div
                className={`w-12 h-7 rounded-full flex items-center justify-center transition ${
                  isActive
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'text-stone-500 group-hover:text-stone-800'
                }`}
              >
                <Icon size={20} strokeWidth={isActive ? 2.5 : 2} />
              </div>
              <span
                className={`text-[10px] tracking-tight mt-0.5 transition ${
                  isActive
                    ? 'font-bold text-emerald-900'
                    : 'font-medium text-stone-500 group-hover:text-stone-700'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}

        {/* 5th button: Open Full 10-section Drawer */}
        <button
          type="button"
          onClick={onOpenDrawer}
          className="flex flex-col items-center justify-center h-full py-1 text-center group cursor-pointer transition min-h-[48px]"
        >
          <div className="w-12 h-7 rounded-full flex items-center justify-center text-stone-500 group-hover:text-stone-800 transition">
            <Menu size={20} />
          </div>
          <span className="text-[10px] font-medium text-stone-500 group-hover:text-stone-700 tracking-tight mt-0.5">
            كل الأقسام
          </span>
        </button>
      </div>
    </nav>
  );
};
