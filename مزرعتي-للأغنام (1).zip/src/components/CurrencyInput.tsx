import React, { useState, useEffect } from 'react';
import { centimesToDzd, dzdToCentimes, formatNumber } from '../utils/formatters';

interface CurrencyInputProps {
  centimesValue: number;
  onChangeCentimes: (centimes: number) => void;
  label?: string;
  required?: boolean;
}

export const CurrencyInput: React.FC<CurrencyInputProps> = ({
  centimesValue,
  onChangeCentimes,
  label = 'المبلغ',
  required = false,
}) => {
  // Mode: user enters in 'centimes' or in 'dzd'
  const [mode, setMode] = useState<'centimes' | 'dzd'>('centimes');
  const [inputValue, setInputValue] = useState<string>(
    centimesValue > 0 ? (mode === 'centimes' ? centimesValue.toString() : centimesToDzd(centimesValue).toString()) : ''
  );

  // Sync when outside prop changes
  useEffect(() => {
    if (mode === 'centimes') {
      setInputValue(centimesValue > 0 ? centimesValue.toString() : '');
    } else {
      const dzd = centimesToDzd(centimesValue);
      setInputValue(dzd > 0 ? dzd.toString() : '');
    }
  }, [centimesValue, mode]);

  const handleInputChange = (raw: string) => {
    // clean number input
    const clean = raw.replace(/[^0-9.]/g, '');
    setInputValue(clean);
    const parsed = parseFloat(clean);

    if (isNaN(parsed) || parsed <= 0) {
      onChangeCentimes(0);
      return;
    }

    if (mode === 'centimes') {
      onChangeCentimes(Math.round(parsed));
    } else {
      onChangeCentimes(dzdToCentimes(parsed));
    }
  };

  const toggleMode = (newMode: 'centimes' | 'dzd') => {
    setMode(newMode);
    if (newMode === 'centimes') {
      setInputValue(centimesValue > 0 ? Math.round(centimesValue).toString() : '');
    } else {
      const dzd = centimesToDzd(centimesValue);
      setInputValue(dzd > 0 ? dzd.toString() : '');
    }
  };

  const convertedDzd = centimesToDzd(centimesValue);
  const convertedCentimes = Math.round(centimesValue);

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-stone-700">
          {label} {required && <span className="text-red-500">*</span>}
        </label>
        {/* Currency Switcher Buttons */}
        <div className="flex bg-stone-100 p-0.5 rounded-lg border border-stone-200">
          <button
            type="button"
            onClick={() => toggleMode('centimes')}
            className={`px-2 py-0.5 text-xs font-medium rounded-md transition ${
              mode === 'centimes'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            بالسنتيم
          </button>
          <button
            type="button"
            onClick={() => toggleMode('dzd')}
            className={`px-2 py-0.5 text-xs font-medium rounded-md transition ${
              mode === 'dzd'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            بالدينار (د.ج)
          </button>
        </div>
      </div>

      <div className="relative">
        <input
          type="text"
          inputMode="numeric"
          value={inputValue}
          onChange={(e) => handleInputChange(e.target.value)}
          placeholder={mode === 'centimes' ? 'مثال: 51900000 (سنتيم)' : 'مثال: 519000 (د.ج)'}
          className="w-full h-11 px-3 text-sm font-semibold rounded-xl border border-stone-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:border-emerald-600 bg-white tabular-nums"
          required={required}
        />
        <div className="absolute left-3 top-2.5 text-xs font-bold text-stone-500 pointer-events-none">
          {mode === 'centimes' ? 'سنتيم' : 'د.ج'}
        </div>
      </div>

      {/* Real-time converted equivalent pill */}
      {centimesValue > 0 && (
        <div className="flex items-center justify-between text-[11px] text-stone-500 bg-stone-50 px-2.5 py-1 rounded-lg border border-stone-200/60 tabular-nums">
          <span>المعادل بالدينار الجزائري:</span>
          <span className="font-bold text-emerald-800">{formatNumber(convertedDzd)} د.ج</span>
          <span className="text-stone-400">|</span>
          <span>المعادل بالسنتيم:</span>
          <span className="font-bold text-stone-700">{formatNumber(convertedCentimes)} سنتيم</span>
        </div>
      )}
    </div>
  );
};
