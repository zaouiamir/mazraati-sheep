import React from 'react';
import { Menu, Bell, Download, Smartphone } from 'lucide-react';
import { NavigationSection } from '../types';

interface AndroidTopBarProps {
  currentSection: NavigationSection;
  onOpenDrawer: () => void;
  onNavigate: (section: NavigationSection) => void;
  unreadRemindersCount: number;
  isInstallable: boolean;
  onInstallApp: () => void;
}

const SECTION_TITLES: Record<NavigationSection, string> = {
  dashboard: 'الرئيسية ومؤشرات القطيع',
  animals: 'إدارة سجل الأغنام',
  reproduction: 'الولادات والتلقيح',
  health: 'السجل الصحي والعلاج',
  feeding: 'التغذية والأعلاف',
  expenses: 'سجل المصاريف',
  income: 'سجل المداخيل والمبيعات',
  reports: 'التقارير المالية والتحليل',
  reminders: 'التنبيهات والمواعيد',
  backup: 'النسخ الاحتياطي والإعدادات',
  android_code: 'كود أندرويد الأصلي (Kotlin + Compose)',
};

export const AndroidTopBar: React.FC<AndroidTopBarProps> = ({
  currentSection,
  onOpenDrawer,
  onNavigate,
  unreadRemindersCount,
  isInstallable,
  onInstallApp,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#1b4332] text-white shadow-md select-none">
      {/* Android Status Bar illusion / top safe zone */}
      <div className="flex items-center justify-between px-4 pt-2.5 pb-2">
        {/* Right side in RTL: Menu burger + App Title */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenDrawer}
            className="w-10 h-10 -mr-1 flex items-center justify-center rounded-full hover:bg-white/10 active:bg-white/20 transition cursor-pointer"
            aria-label="فتح القائمة الرئيسية"
          >
            <Menu size={22} className="text-white" />
          </button>

          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="text-base font-bold tracking-tight text-white leading-tight">
                مزرعتي للأغنام
              </h1>
              <span className="text-[10px] font-medium bg-emerald-600/80 text-emerald-100 px-1.5 py-0.2 rounded-md">
                Android
              </span>
            </div>
            <p className="text-[11px] text-emerald-200/90 font-medium truncate max-w-[200px] sm:max-w-xs">
              {SECTION_TITLES[currentSection]}
            </p>
          </div>
        </div>

        {/* Left side in RTL: Actions (PWA install + Reminders) */}
        <div className="flex items-center gap-1.5">
          {/* Android Code Project shortcut */}
          <button
            type="button"
            onClick={() => onNavigate('android_code')}
            className={`hidden sm:flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
              currentSection === 'android_code'
                ? 'bg-emerald-600 text-white'
                : 'bg-emerald-900/60 text-emerald-200 hover:bg-emerald-800/80'
            }`}
            title="مشاهدة وتحميل مشروع أندرويد ستوديو"
          >
            <Smartphone size={14} />
            <span>مشروع Kotlin</span>
          </button>

          {/* Install PWA Button if available */}
          {isInstallable && (
            <button
              type="button"
              onClick={onInstallApp}
              className="flex items-center gap-1 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-stone-900 font-bold rounded-lg text-xs shadow-xs transition cursor-pointer min-h-[36px]"
              title="تثبيت التطبيق على الهاتف"
            >
              <Download size={14} />
              <span className="hidden xs:inline">تثبيت التطبيق</span>
            </button>
          )}

          {/* Reminders Bell with Counter Badge */}
          <button
            type="button"
            onClick={() => onNavigate('reminders')}
            className="relative w-10 h-10 flex items-center justify-center rounded-full hover:bg-white/10 active:bg-white/20 transition cursor-pointer"
            aria-label="التنبيهات"
          >
            <Bell size={20} className="text-white" />
            {unreadRemindersCount > 0 && (
              <span className="absolute top-1.5 right-1.5 min-w-[18px] h-[18px] flex items-center justify-center bg-red-500 text-white text-[10px] font-bold rounded-full px-1 shadow-xs border-2 border-[#1b4332]">
                {unreadRemindersCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
