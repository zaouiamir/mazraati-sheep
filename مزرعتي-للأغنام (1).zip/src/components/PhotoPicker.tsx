import React, { useRef } from 'react';
import { Camera, Image as ImageIcon, X } from 'lucide-react';

interface PhotoPickerProps {
  value?: string;
  onChange: (base64: string | undefined) => void;
  label?: string;
}

export const PhotoPicker: React.FC<PhotoPickerProps> = ({
  value,
  onChange,
  label = 'صورة فوتوغرافية',
}) => {
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const galleryInputRef = useRef<HTMLInputElement>(null);

  const processFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        // Compress image using canvas
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', 0.75);
          onChange(compressed);
        }
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  return (
    <div className="space-y-1.5">
      <label className="block text-xs font-semibold text-stone-700">{label}</label>

      {value ? (
        <div className="relative inline-block rounded-xl overflow-hidden border border-stone-200 shadow-xs">
          <img
            src={value}
            alt="صورة ملتقطة"
            className="w-32 h-32 object-cover"
            referrerPolicy="no-referrer"
          />
          <button
            type="button"
            onClick={() => onChange(undefined)}
            className="absolute top-1 right-1 p-1 bg-red-600 text-white rounded-full shadow-sm hover:bg-red-700 transition"
            title="حذف الصورة"
          >
            <X size={14} />
          </button>
        </div>
      ) : (
        <div className="flex gap-2">
          {/* Camera input (direct capture) */}
          <input
            type="file"
            accept="image/*"
            capture="environment"
            ref={cameraInputRef}
            onChange={handleFileChange}
            className="hidden"
          />
          {/* Gallery input */}
          <input
            type="file"
            accept="image/*"
            ref={galleryInputRef}
            onChange={handleFileChange}
            className="hidden"
          />

          <button
            type="button"
            onClick={() => cameraInputRef.current?.click()}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 border border-dashed border-emerald-600/50 rounded-xl text-emerald-800 bg-emerald-50/50 hover:bg-emerald-50 text-xs font-medium transition cursor-pointer min-h-[44px]"
          >
            <Camera size={16} />
            <span>التقاط بالكاميرا</span>
          </button>

          <button
            type="button"
            onClick={() => galleryInputRef.current?.click()}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 px-3 border border-dashed border-stone-300 rounded-xl text-stone-700 bg-stone-50 hover:bg-stone-100 text-xs font-medium transition cursor-pointer min-h-[44px]"
          >
            <ImageIcon size={16} />
            <span>من المعرض</span>
          </button>
        </div>
      )}
    </div>
  );
};
