/**
 * Mazraati Sheep (مزرعتي للأغنام) - Currency & Date Utilities
 * 1 DZD = 100 Centimes (سنتيم)
 */

export function centimesToDzd(centimes: number): number {
  return Math.round(centimes) / 100;
}

export function dzdToCentimes(dzd: number): number {
  return Math.round(dzd * 100);
}

/**
 * Format numbers with thousand separators
 */
export function formatNumber(num: number): string {
  return new Intl.NumberFormat('fr-DZ', {
    maximumFractionDigits: 2,
    minimumFractionDigits: 0,
  }).format(num);
}

/**
 * Format Algerian Dinar: e.g. "1,200,000 د.ج"
 */
export function formatDzd(centimes: number): string {
  const dzd = centimesToDzd(centimes);
  return `${formatNumber(dzd)} د.ج`;
}

/**
 * Format Centimes: e.g. "120,000,000 سنتيم"
 */
export function formatCentimes(centimes: number): string {
  return `${formatNumber(Math.round(centimes))} سنتيم`;
}

/**
 * Dual Currency Display
 * e.g. "67,400 د.ج (6,740,000 سنتيم)"
 */
export function formatDualCurrency(
  centimes: number,
  mode: 'both' | 'centimes' | 'dzd' = 'both'
): string {
  if (mode === 'dzd') return formatDzd(centimes);
  if (mode === 'centimes') return formatCentimes(centimes);
  return `${formatDzd(centimes)} (${formatCentimes(centimes)})`;
}

/**
 * Calculate precise age in Arabic: years, months, days
 */
export function calculateAgeArabic(birthDateStr: string, referenceDateStr?: string): string {
  if (!birthDateStr) return 'غير محدد';
  
  const birth = new Date(birthDateStr);
  const now = referenceDateStr ? new Date(referenceDateStr) : new Date();
  
  if (isNaN(birth.getTime())) return 'تاريخ غير صالح';
  if (birth > now) return 'حديث الولادة';

  let years = now.getFullYear() - birth.getFullYear();
  let months = now.getMonth() - birth.getMonth();
  let days = now.getDate() - birth.getDate();

  if (days < 0) {
    months -= 1;
    const prevMonthLastDay = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
    days += prevMonthLastDay;
  }

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  const parts: string[] = [];

  if (years > 0) {
    if (years === 1) parts.push('سنة');
    else if (years === 2) parts.push('سنتان');
    else if (years >= 3 && years <= 10) parts.push(`${years} سنوات`);
    else parts.push(`${years} سنة`);
  }

  if (months > 0) {
    if (months === 1) parts.push('شهر واحد');
    else if (months === 2) parts.push('شهران');
    else if (months >= 3 && months <= 10) parts.push(`${months} أشهر`);
    else parts.push(`${months} شهراً`);
  }

  if (days > 0 || parts.length === 0) {
    if (days === 1) parts.push('يوم واحد');
    else if (days === 2) parts.push('يومان');
    else if (days >= 3 && days <= 10) parts.push(`${days} أيام`);
    else parts.push(`${days} يوماً`);
  }

  return parts.join(' و ');
}

/**
 * Calculate expected lambing date (average 148 days, 147–150 days)
 */
export function calculateExpectedLambing(matingDateStr: string, days: number = 148): string {
  const mating = new Date(matingDateStr);
  if (isNaN(mating.getTime())) return '';
  const expected = new Date(mating.getTime() + days * 24 * 60 * 60 * 1000);
  return expected.toISOString().split('T')[0];
}

/**
 * Calculate days remaining until lambing
 */
export function getDaysUntilLambing(expectedDateStr: string): {
  days: number;
  isOverdue: boolean;
  text: string;
} {
  const expected = new Date(expectedDateStr);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  expected.setHours(0, 0, 0, 0);

  const diffTime = expected.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays === 0) {
    return { days: 0, isOverdue: false, text: 'اليوم موعد الولادة!' };
  } else if (diffDays > 0) {
    return { days: diffDays, isOverdue: false, text: `متبقي ${diffDays} يوم` };
  } else {
    return { days: Math.abs(diffDays), isOverdue: true, text: `متأخر بـ ${Math.abs(diffDays)} يوم` };
  }
}

/**
 * Format Date to readable Arabic text
 */
export function formatDateArabic(dateStr: string): string {
  if (!dateStr) return '';
  const date = new Date(dateStr);
  if (isNaN(date.getTime())) return dateStr;

  const months = [
    'جانفي', 'فيفري', 'مارس', 'أفريل', 'ماي', 'جوان',
    'جويلية', 'أوت', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
  ];

  const day = date.getDate();
  const month = months[date.getMonth()];
  const year = date.getFullYear();

  return `${day} ${month} ${year}`;
}
